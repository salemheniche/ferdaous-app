# دليل تثبيت منصة الفردوس — Laravel

## متطلبات التشغيل
- PHP 8.1 أو أعلى
- Composer
- MySQL (مدمج مع Laragon أو XAMPP)
- Laravel (سيُثبَّت تلقائياً عبر Composer)

---

## خطوات التثبيت على جهازك المحلي (Laragon)

### 1. افتح Terminal داخل Laragon وشغّل:

```bash
composer create-project laravel/laravel ferdaous-laravel
cd ferdaous-laravel
```

### 2. انسخ ملفات هذا المشروع إلى داخل مجلد ferdaous-laravel
استبدل الملفات الموجودة بالملفات من هذا المشروع.

### 3. ضبط قاعدة البيانات

افتح **Laragon → phpMyAdmin** أو شغّل:
```sql
CREATE DATABASE ferdaous_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 4. إعداد ملف .env

```bash
cp .env.example .env
```

ثم عدّل هذه الأسطر:
```
DB_DATABASE=ferdaous_db
DB_USERNAME=root
DB_PASSWORD=          # اتركه فارغاً إذا Laragon بدون كلمة مرور
```

### 5. توليد المفتاح وتشغيل Migrations

```bash
php artisan key:generate
php artisan migrate
php artisan db:seed
```

### 6. تشغيل الخادم

```bash
php artisan serve
```

افتح المتصفح على: **http://localhost:8000**

**بيانات الدخول:** `admin` / `admin123`

---

## النشر على cPanel

### 1. رفع الملفات
- ارفع محتوى المجلد `public/` إلى `public_html/`
- ارفع باقي الملفات إلى مجلد خارج `public_html` (مثلاً `ferdaous-app/`)

### 2. تعديل public/index.php
```php
require __DIR__.'/../ferdaous-app/vendor/autoload.php';
$app = require_once __DIR__.'/../ferdaous-app/bootstrap/app.php';
```

### 3. إنشاء قاعدة البيانات في cPanel
- افتح **MySQL Databases**
- أنشئ قاعدة بيانات ومستخدم
- عدّل `.env` بالبيانات الجديدة

### 4. تشغيل Migrations عبر Terminal أو PHP Runner
```bash
php artisan migrate --seed
```

### 5. ضبط Session
في `.env`:
```
SESSION_DRIVER=file
```

---

## هيكل المشروع

```
app/Http/Controllers/    ← 13 Controller
database/migrations/     ← Migration واحد لكل الجداول
database/seeders/        ← مستخدم admin افتراضي + إعدادات
resources/views/         ← Blade views لكل صفحة
routes/web.php           ← كل الروابط
```

## الصفحات المتاحة

| الصفحة | الرابط |
|--------|--------|
| الداشبورد | `/dashboard` |
| الطلاب | `/students` |
| المعلمون | `/teachers` |
| الأفواج | `/groups` |
| الحضور | `/attendance` |
| التواصل | `/attendance/contact` |
| الجداول | `/schedules` |
| المالية | `/finance` |
| التقارير | `/reports` |
| البطاقات | `/reports/cards` |
| المواد | `/subjects` |
| القاعات | `/rooms` |
| المستخدمون | `/users` |
| الإعدادات | `/settings` |
| النسخ الاحتياطي | `/backup` |
