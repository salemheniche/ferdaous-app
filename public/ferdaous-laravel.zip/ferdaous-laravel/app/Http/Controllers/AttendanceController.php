<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AttendanceController extends Controller
{
    public function index(Request $request)
    {
        $groups    = DB::table('groups')->where('status', 'open')->orderBy('name')->get();
        $date      = $request->input('date', now()->toDateString());
        $groupId   = $request->input('group_id');
        $students  = collect();
        $attendances = collect();

        if ($groupId) {
            $students = DB::table('group_students')
                ->join('students', 'students.id', '=', 'group_students.student_id')
                ->where('group_students.group_id', $groupId)
                ->where('students.status', 'active')
                ->select('students.*')
                ->get();

            $attendances = DB::table('attendances')
                ->where('attendance_date', $date)
                ->whereIn('student_id', $students->pluck('id'))
                ->get()
                ->keyBy('student_id');
        }

        return view('attendance.index', compact('groups', 'date', 'groupId', 'students', 'attendances'));
    }

    public function store(Request $request)
    {
        $date     = $request->input('date', now()->toDateString());
        $records  = $request->input('records', []);

        foreach ($records as $studentId => $data) {
            $existing = DB::table('attendances')
                ->where('student_id', $studentId)
                ->where('attendance_date', $date)
                ->first();

            if ($existing) {
                DB::table('attendances')->where('id', $existing->id)->update([
                    'status'     => $data['status'] ?? 'present',
                    'notes'      => $data['notes'] ?? null,
                    'updated_at' => now(),
                ]);
            } else {
                DB::table('attendances')->insert([
                    'student_id'      => $studentId,
                    'attendance_date' => $date,
                    'status'          => $data['status'] ?? 'present',
                    'notes'           => $data['notes'] ?? null,
                    'created_at'      => now(),
                    'updated_at'      => now(),
                ]);
            }

            // Auto-withdraw if 5+ absences
            $absenceCount = DB::table('attendances')
                ->where('student_id', $studentId)
                ->where('status', 'absent')
                ->count();
            if ($absenceCount >= 5) {
                DB::table('students')->where('id', $studentId)->update(['status' => 'withdrawn']);
            }
        }

        return redirect()->back()->with('success', 'تم حفظ الحضور بنجاح');
    }

    public function contact(Request $request)
    {
        $date    = $request->input('date', now()->toDateString());
        $settings = DB::table('settings')->pluck('value', 'key');

        $absent = DB::table('attendances')
            ->join('students', 'students.id', '=', 'attendances.student_id')
            ->whereIn('attendances.status', ['absent', 'late'])
            ->where('attendances.attendance_date', $date)
            ->select('students.*', 'attendances.status as attendance_status')
            ->get();

        return view('attendance.contact', compact('absent', 'date', 'settings'));
    }
}
