<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AuthController extends Controller
{
    public function showLogin()
    {
        if (session('user')) return redirect()->route('dashboard');
        return view('auth.login');
    }

    public function login(Request $request)
    {
        $username = trim($request->input('username'));
        $password = $request->input('password');

        if (!$username || !$password) {
            return back()->with('error', 'يرجى إدخال بيانات الدخول');
        }

        $hashed = hash('sha256', $password);

        $user = DB::table('users')
            ->where(function ($q) use ($username) {
                $q->where('username', $username)->orWhere('phone', $username);
            })
            ->where('password', $hashed)
            ->first();

        if (!$user) {
            return back()->with('error', 'اسم المستخدم أو كلمة المرور غير صحيحة');
        }

        if ($user->status !== 'active') {
            return back()->with('error', 'هذا الحساب غير مفعل');
        }

        session(['user' => [
            'id'        => $user->id,
            'role'      => $user->role,
            'username'  => $user->username,
            'full_name' => $user->full_name,
            'teacher_id'=> $user->teacher_id,
        ]]);

        return redirect()->route('dashboard');
    }

    public function logout(Request $request)
    {
        $request->session()->forget('user');
        return redirect()->route('login');
    }
}
