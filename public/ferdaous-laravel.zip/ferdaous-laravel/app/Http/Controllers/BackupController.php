<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;

class BackupController extends Controller
{
    public function index()
    {
        return view('settings.backup');
    }

    public function download()
    {
        $data = [
            'students'        => DB::table('students')->get(),
            'teachers'        => DB::table('teachers')->get(),
            'groups'          => DB::table('groups')->get(),
            'group_students'  => DB::table('group_students')->get(),
            'subjects'        => DB::table('subjects')->get(),
            'rooms'           => DB::table('rooms')->get(),
            'schedules'       => DB::table('schedules')->get(),
            'attendances'     => DB::table('attendances')->get(),
            'fee_payments'    => DB::table('fee_payments')->get(),
            'expenses'        => DB::table('expenses')->get(),
            'donations'       => DB::table('donations')->get(),
            'salary_payments' => DB::table('salary_payments')->get(),
            'settings'        => DB::table('settings')->get(),
            'exported_at'     => now()->toDateTimeString(),
        ];

        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        $filename = 'backup_' . now()->format('Ymd_His') . '.json';

        return response($json, 200, [
            'Content-Type'        => 'application/json',
            'Content-Disposition' => "attachment; filename=$filename",
        ]);
    }
}
