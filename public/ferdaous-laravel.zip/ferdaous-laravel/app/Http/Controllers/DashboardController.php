<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        $students = DB::table('students');
        $stats = [
            'total_students'     => $students->count(),
            'active_students'    => (clone $students)->where('status', 'active')->count(),
            'waiting_students'   => (clone $students)->where('status', 'waiting')->count(),
            'withdrawn_students' => (clone $students)->where('status', 'withdrawn')->count(),
            'graduated_students' => (clone $students)->where('status', 'graduated')->count(),
            'total_teachers'     => DB::table('teachers')->where('status', 'active')->count(),
            'total_groups'       => DB::table('groups')->count(),
            'open_groups'        => DB::table('groups')->where('status', 'open')->count(),
        ];

        // Groups without attendance today
        $today = now()->toDateString();
        $allGroups = DB::table('groups')->where('status', 'open')->get();
        $groupsWithAttendance = DB::table('attendances')
            ->where('attendance_date', $today)
            ->pluck('student_id');

        $groupsToday = [];
        foreach ($allGroups as $group) {
            $studentIds = DB::table('group_students')
                ->where('group_id', $group->id)
                ->pluck('student_id');
            $hasAttendance = $groupsWithAttendance->intersect($studentIds)->isNotEmpty();
            if (!$hasAttendance && $studentIds->isNotEmpty()) {
                $groupsToday[] = $group;
            }
        }

        $schoolName = DB::table('settings')->where('key', 'school_name')->value('value') ?? 'مؤسسة الفردوس';

        return view('dashboard.index', compact('stats', 'groupsToday', 'schoolName'));
    }
}
