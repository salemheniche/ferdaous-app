<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class FinanceController extends Controller
{
    public function index()
    {
        $fees      = DB::table('fee_payments')->join('students', 'students.id', '=', 'fee_payments.student_id')->select('fee_payments.*', DB::raw("CONCAT(students.first_name,' ',students.last_name) as student_name"))->orderByDesc('fee_payments.id')->get();
        $expenses  = DB::table('expenses')->orderByDesc('id')->get();
        $donations = DB::table('donations')->orderByDesc('id')->get();
        $salaries  = DB::table('salary_payments')->join('teachers', 'teachers.id', '=', 'salary_payments.teacher_id')->select('salary_payments.*', 'teachers.full_name as teacher_name')->orderByDesc('salary_payments.id')->get();
        $students  = DB::table('students')->where('status', 'active')->orderBy('first_name')->get();
        $teachers  = DB::table('teachers')->where('status', 'active')->orderBy('full_name')->get();

        $totalFees      = $fees->sum(fn($f) => floatval($f->amount));
        $totalExpenses  = $expenses->sum(fn($e) => floatval($e->amount));
        $totalDonations = $donations->sum(fn($d) => floatval($d->amount));
        $totalSalaries  = $salaries->sum(fn($s) => floatval($s->net_salary));
        $totalIncome    = $totalFees + $totalDonations;
        $totalOutcome   = $totalExpenses + $totalSalaries;
        $netBalance     = $totalIncome - $totalOutcome;

        return view('finance.index', compact(
            'fees','expenses','donations','salaries',
            'students','teachers',
            'totalFees','totalExpenses','totalDonations','totalSalaries',
            'totalIncome','totalOutcome','netBalance'
        ));
    }

    public function storeFee(Request $request)
    {
        DB::table('fee_payments')->insert([
            'student_id'   => $request->student_id,
            'amount'       => $request->amount,
            'payment_date' => $request->payment_date ?: now()->toDateString(),
            'for_month'    => $request->for_month,
            'notes'        => $request->notes,
            'created_at'   => now(), 'updated_at' => now(),
        ]);
        return redirect()->route('finance.index', ['tab' => 'fees'])->with('success', 'تم تسجيل الدفع');
    }

    public function destroyFee($id)
    {
        DB::table('fee_payments')->where('id', $id)->delete();
        return redirect()->route('finance.index', ['tab' => 'fees'])->with('success', 'تم الحذف');
    }

    public function storeExpense(Request $request)
    {
        DB::table('expenses')->insert([
            'category'     => $request->category,
            'amount'       => $request->amount,
            'expense_date' => $request->expense_date ?: now()->toDateString(),
            'notes'        => $request->notes,
            'created_at'   => now(), 'updated_at' => now(),
        ]);
        return redirect()->route('finance.index', ['tab' => 'expenses'])->with('success', 'تم تسجيل المصروف');
    }

    public function destroyExpense($id)
    {
        DB::table('expenses')->where('id', $id)->delete();
        return redirect()->route('finance.index', ['tab' => 'expenses'])->with('success', 'تم الحذف');
    }

    public function storeDonation(Request $request)
    {
        DB::table('donations')->insert([
            'donor_name'    => $request->donor_name,
            'amount'        => $request->amount,
            'donation_date' => $request->donation_date ?: now()->toDateString(),
            'notes'         => $request->notes,
            'created_at'    => now(), 'updated_at' => now(),
        ]);
        return redirect()->route('finance.index', ['tab' => 'donations'])->with('success', 'تم تسجيل التبرع');
    }

    public function destroyDonation($id)
    {
        DB::table('donations')->where('id', $id)->delete();
        return redirect()->route('finance.index', ['tab' => 'donations'])->with('success', 'تم الحذف');
    }

    public function storeSalary(Request $request)
    {
        $base      = floatval($request->base_salary);
        $bonus     = floatval($request->bonus ?? 0);
        $deduction = floatval($request->deduction ?? 0);
        $net       = $base + $bonus - $deduction;

        DB::table('salary_payments')->insert([
            'teacher_id'   => $request->teacher_id,
            'for_month'    => $request->for_month,
            'base_salary'  => $base,
            'bonus'        => $bonus,
            'deduction'    => $deduction,
            'net_salary'   => $net,
            'payment_date' => $request->payment_date ?: now()->toDateString(),
            'created_at'   => now(), 'updated_at' => now(),
        ]);
        return redirect()->route('finance.index', ['tab' => 'salaries'])->with('success', 'تم تسجيل الراتب');
    }

    public function destroySalary($id)
    {
        DB::table('salary_payments')->where('id', $id)->delete();
        return redirect()->route('finance.index', ['tab' => 'salaries'])->with('success', 'تم الحذف');
    }
}
