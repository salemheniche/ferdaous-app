<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class GroupController extends Controller
{
    public function index()
    {
        $groups = DB::table('groups')
            ->leftJoin('rooms', 'rooms.id', '=', 'groups.room_id')
            ->select('groups.*', 'rooms.name as room_name')
            ->orderByDesc('groups.id')
            ->get();

        foreach ($groups as &$g) {
            $g->student_count = DB::table('group_students')->where('group_id', $g->id)->count();
        }

        $students  = DB::table('students')->where('status', 'active')->orderBy('first_name')->get();
        $rooms     = DB::table('rooms')->get();
        return view('groups.index', compact('groups', 'students', 'rooms'));
    }

    public function show($id)
    {
        $group = DB::table('groups')->where('id', $id)->first();
        abort_if(!$group, 404);

        $students = DB::table('group_students')
            ->join('students', 'students.id', '=', 'group_students.student_id')
            ->where('group_students.group_id', $id)
            ->select('students.*', 'group_students.joined_date')
            ->get();

        $allStudents = DB::table('students')->where('status', 'active')->orderBy('first_name')->get();
        return view('groups.show', compact('group', 'students', 'allStudents'));
    }

    public function store(Request $request)
    {
        $request->validate(['name' => 'required|string|max:100']);

        $lastId = DB::table('groups')->max('id') ?? 0;
        $groupNumber = 'G' . str_pad($lastId + 1, 4, '0', STR_PAD_LEFT);

        DB::table('groups')->insert([
            'group_number' => $groupNumber,
            'name'         => $request->name,
            'group_type'   => $request->group_type,
            'room_id'      => $request->room_id,
            'capacity'     => $request->capacity,
            'status'       => $request->status ?? 'open',
            'created_at'   => now(),
            'updated_at'   => now(),
        ]);

        return redirect()->route('groups.index')->with('success', 'تم إنشاء الفوج بنجاح');
    }

    public function edit($id)
    {
        $group = DB::table('groups')->where('id', $id)->first();
        abort_if(!$group, 404);
        $rooms = DB::table('rooms')->get();
        return view('groups.edit', compact('group', 'rooms'));
    }

    public function update(Request $request, $id)
    {
        DB::table('groups')->where('id', $id)->update([
            'name'       => $request->name,
            'group_type' => $request->group_type,
            'room_id'    => $request->room_id,
            'capacity'   => $request->capacity,
            'status'     => $request->status ?? 'open',
            'updated_at' => now(),
        ]);
        return redirect()->route('groups.index')->with('success', 'تم تحديث الفوج');
    }

    public function destroy($id)
    {
        DB::table('groups')->where('id', $id)->delete();
        return redirect()->route('groups.index')->with('success', 'تم حذف الفوج');
    }

    public function addStudent(Request $request, $id)
    {
        $studentId = $request->student_id;
        $exists = DB::table('group_students')
            ->where('group_id', $id)->where('student_id', $studentId)->exists();
        if (!$exists) {
            DB::table('group_students')->insert([
                'group_id'    => $id,
                'student_id'  => $studentId,
                'joined_date' => now()->toDateString(),
            ]);
        }
        return redirect()->route('groups.show', $id)->with('success', 'تم إضافة الطالب للفوج');
    }

    public function removeStudent($id, $studentId)
    {
        DB::table('group_students')
            ->where('group_id', $id)->where('student_id', $studentId)->delete();
        return redirect()->route('groups.show', $id)->with('success', 'تم إزالة الطالب من الفوج');
    }
}
