<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    public function index()
    {
        $students = DB::table('students');
        $stats = [
            'total_students'     => $students->count(),
            'active_students'    => (clone $students)->where('status','active')->count(),
            'withdrawn_students' => (clone $students)->where('status','withdrawn')->count(),
            'waiting_students'   => (clone $students)->where('status','waiting')->count(),
            'graduated_students' => (clone $students)->where('status','graduated')->count(),
            'total_teachers'     => DB::table('teachers')->where('status','active')->count(),
            'total_groups'       => DB::table('groups')->count(),
        ];

        $totalFees      = DB::table('fee_payments')->sum(DB::raw('CAST(amount AS DECIMAL(10,2))'));
        $totalExpenses  = DB::table('expenses')->sum(DB::raw('CAST(amount AS DECIMAL(10,2))'));
        $totalDonations = DB::table('donations')->sum(DB::raw('CAST(amount AS DECIMAL(10,2))'));
        $totalSalaries  = DB::table('salary_payments')->sum(DB::raw('CAST(net_salary AS DECIMAL(10,2))'));

        $groups   = DB::table('groups')->orderBy('name')->get();
        $settings = DB::table('settings')->pluck('value', 'key');

        return view('reports.index', compact('stats','totalFees','totalExpenses','totalDonations','totalSalaries','groups','settings'));
    }

    public function cards(Request $request)
    {
        $groupId = $request->input('group_id');
        $theme   = $request->input('theme', 'green');
        $showYear  = $request->boolean('show_year', true);
        $showGroup = $request->boolean('show_group', true);

        $groups   = DB::table('groups')->orderBy('name')->get();
        $students = collect();

        if ($groupId) {
            $students = DB::table('group_students')
                ->join('students', 'students.id', '=', 'group_students.student_id')
                ->leftJoin('groups', 'groups.id', '=', 'group_students.group_id')
                ->where('group_students.group_id', $groupId)
                ->select('students.*', 'groups.name as group_name')
                ->get();
        }

        $settings = DB::table('settings')->pluck('value', 'key');

        return view('reports.cards', compact('groups','students','groupId','theme','showYear','showGroup','settings'));
    }
}
