<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RoomController extends Controller
{
    public function index()
    {
        $rooms = DB::table('rooms')->orderByDesc('id')->get();
        return view('rooms.index', compact('rooms'));
    }

    public function store(Request $request)
    {
        $request->validate(['name' => 'required|string|max:100']);
        DB::table('rooms')->insert([
            'name'        => $request->name,
            'room_number' => $request->room_number,
            'floor'       => $request->floor,
            'capacity'    => $request->capacity,
            'status'      => $request->status ?? 'available',
            'equipment'   => $request->equipment,
            'created_at'  => now(), 'updated_at' => now(),
        ]);
        return redirect()->route('rooms.index')->with('success', 'تم إضافة القاعة');
    }

    public function edit($id)
    {
        $room = DB::table('rooms')->where('id', $id)->first();
        return view('rooms.edit', compact('room'));
    }

    public function update(Request $request, $id)
    {
        DB::table('rooms')->where('id', $id)->update([
            'name'        => $request->name,
            'room_number' => $request->room_number,
            'floor'       => $request->floor,
            'capacity'    => $request->capacity,
            'status'      => $request->status ?? 'available',
            'equipment'   => $request->equipment,
            'updated_at'  => now(),
        ]);
        return redirect()->route('rooms.index')->with('success', 'تم التحديث');
    }

    public function destroy($id)
    {
        DB::table('rooms')->where('id', $id)->delete();
        return redirect()->route('rooms.index')->with('success', 'تم الحذف');
    }
}
