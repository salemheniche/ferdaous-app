<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ScheduleController extends Controller
{
    public function index()
    {
        $schedules = DB::table('schedules')
            ->leftJoin('groups',   'groups.id',   '=', 'schedules.group_id')
            ->leftJoin('subjects', 'subjects.id', '=', 'schedules.subject_id')
            ->leftJoin('teachers', 'teachers.id', '=', 'schedules.teacher_id')
            ->leftJoin('rooms',    'rooms.id',    '=', 'schedules.room_id')
            ->select('schedules.*',
                'groups.name as group_name',
                'subjects.name as subject_name',
                'teachers.full_name as teacher_name',
                'rooms.name as room_name')
            ->orderByRaw("FIELD(day_of_week,'الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت')")
            ->orderBy('start_time')
            ->get();

        $groups   = DB::table('groups')->where('status','open')->get();
        $subjects = DB::table('subjects')->get();
        $teachers = DB::table('teachers')->where('status','active')->get();
        $rooms    = DB::table('rooms')->get();
        $days     = ['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];

        return view('schedules.index', compact('schedules','groups','subjects','teachers','rooms','days'));
    }

    public function store(Request $request)
    {
        DB::table('schedules')->insert([
            'day_of_week' => $request->day_of_week,
            'start_time'  => $request->start_time,
            'end_time'    => $request->end_time,
            'group_id'    => $request->group_id,
            'subject_id'  => $request->subject_id,
            'teacher_id'  => $request->teacher_id,
            'room_id'     => $request->room_id,
            'created_at'  => now(), 'updated_at' => now(),
        ]);
        return redirect()->route('schedules.index')->with('success', 'تم إضافة الحصة');
    }

    public function update(Request $request, $id)
    {
        DB::table('schedules')->where('id', $id)->update([
            'day_of_week' => $request->day_of_week,
            'start_time'  => $request->start_time,
            'end_time'    => $request->end_time,
            'group_id'    => $request->group_id,
            'subject_id'  => $request->subject_id,
            'teacher_id'  => $request->teacher_id,
            'room_id'     => $request->room_id,
            'updated_at'  => now(),
        ]);
        return redirect()->route('schedules.index')->with('success', 'تم تحديث الحصة');
    }

    public function destroy($id)
    {
        DB::table('schedules')->where('id', $id)->delete();
        return redirect()->route('schedules.index')->with('success', 'تم حذف الحصة');
    }

    public function generate(Request $request)
    {
        $days      = $request->input('days', []);
        $startTime = $request->start_time;
        $endTime   = $request->end_time;
        $groupId   = $request->group_id;
        $subjectId = $request->subject_id;
        $teacherId = $request->teacher_id;
        $roomId    = $request->room_id;
        $created   = 0;

        foreach ($days as $day) {
            // Conflict check: teacher busy that day
            $teacherConflict = DB::table('schedules')
                ->where('teacher_id', $teacherId)->where('day_of_week', $day)->exists();
            // Conflict check: room busy that day
            $roomConflict = $roomId && DB::table('schedules')
                ->where('room_id', $roomId)->where('day_of_week', $day)->exists();

            if (!$teacherConflict && !$roomConflict) {
                DB::table('schedules')->insert([
                    'day_of_week' => $day,
                    'start_time'  => $startTime,
                    'end_time'    => $endTime,
                    'group_id'    => $groupId,
                    'subject_id'  => $subjectId,
                    'teacher_id'  => $teacherId,
                    'room_id'     => $roomId,
                    'created_at'  => now(), 'updated_at' => now(),
                ]);
                $created++;
            }
        }

        return redirect()->route('schedules.index')->with('success', "تم إنشاء $created حصة تلقائياً");
    }
}
