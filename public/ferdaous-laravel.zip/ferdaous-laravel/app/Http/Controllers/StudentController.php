<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StudentController extends Controller
{
    public function index(Request $request)
    {
        $query = DB::table('students');

        if ($search = $request->input('search')) {
            $query->where(function ($q) use ($search) {
                $q->where('first_name', 'like', "%$search%")
                  ->orWhere('last_name', 'like', "%$search%")
                  ->orWhere('student_number', 'like', "%$search%");
            });
        }
        if ($gender = $request->input('gender')) {
            $query->where('gender', $gender);
        }
        if ($status = $request->input('status')) {
            $query->where('status', $status);
        }

        $students = $query->orderByDesc('id')->paginate(20)->withQueryString();
        return view('students.index', compact('students'));
    }

    public function create()
    {
        return view('students.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'first_name' => 'required|string|max:100',
            'last_name'  => 'required|string|max:100',
        ]);

        $lastId = DB::table('students')->max('id') ?? 0;
        $studentNumber = 'FD' . str_pad($lastId + 1, 4, '0', STR_PAD_LEFT);

        DB::table('students')->insert([
            'student_number'    => $studentNumber,
            'first_name'        => $request->first_name,
            'last_name'         => $request->last_name,
            'gender'            => $request->gender,
            'phone'             => $request->phone,
            'guardian_name'     => $request->guardian_name,
            'educational_level' => $request->educational_level,
            'enrollment_date'   => $request->enrollment_date ?: now()->toDateString(),
            'birth_date'        => $request->birth_date,
            'address'           => $request->address,
            'notes'             => $request->notes,
            'status'            => 'waiting',
            'created_at'        => now(),
            'updated_at'        => now(),
        ]);

        return redirect()->route('students.index')->with('success', 'تم إضافة الطالب بنجاح');
    }

    public function show($id)
    {
        $student = DB::table('students')->where('id', $id)->first();
        abort_if(!$student, 404);

        $groups = DB::table('group_students')
            ->join('groups', 'groups.id', '=', 'group_students.group_id')
            ->where('group_students.student_id', $id)
            ->select('groups.*')
            ->get();

        $absenceCount = DB::table('attendances')
            ->where('student_id', $id)
            ->where('status', 'absent')
            ->count();

        return view('students.show', compact('student', 'groups', 'absenceCount'));
    }

    public function edit($id)
    {
        $student = DB::table('students')->where('id', $id)->first();
        abort_if(!$student, 404);
        return view('students.edit', compact('student'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'first_name' => 'required|string|max:100',
            'last_name'  => 'required|string|max:100',
        ]);

        DB::table('students')->where('id', $id)->update([
            'first_name'        => $request->first_name,
            'last_name'         => $request->last_name,
            'gender'            => $request->gender,
            'phone'             => $request->phone,
            'guardian_name'     => $request->guardian_name,
            'educational_level' => $request->educational_level,
            'enrollment_date'   => $request->enrollment_date,
            'birth_date'        => $request->birth_date,
            'address'           => $request->address,
            'notes'             => $request->notes,
            'status'            => $request->status,
            'updated_at'        => now(),
        ]);

        return redirect()->route('students.index')->with('success', 'تم تحديث بيانات الطالب');
    }

    public function destroy($id)
    {
        DB::table('students')->where('id', $id)->delete();
        return redirect()->route('students.index')->with('success', 'تم حذف الطالب');
    }

    public function printProfile($id)
    {
        $student = DB::table('students')->where('id', $id)->first();
        abort_if(!$student, 404);

        $groups = DB::table('group_students')
            ->join('groups', 'groups.id', '=', 'group_students.group_id')
            ->where('group_students.student_id', $id)
            ->select('groups.*')
            ->get();

        $absenceCount = DB::table('attendances')
            ->where('student_id', $id)
            ->where('status', 'absent')
            ->count();

        $schoolName = DB::table('settings')->where('key', 'school_name')->value('value') ?? 'مؤسسة الفردوس';
        $academicYear = DB::table('settings')->where('key', 'academic_year')->value('value') ?? '2025/2026';

        return view('students.print', compact('student', 'groups', 'absenceCount', 'schoolName', 'academicYear'));
    }

    public function exportExcel()
    {
        $students = DB::table('students')->orderBy('id')->get();
        $filename = 'students_' . now()->format('Ymd') . '.csv';

        $headers = [
            'Content-Type' => 'text/csv; charset=UTF-8',
            'Content-Disposition' => "attachment; filename=$filename",
        ];

        $callback = function () use ($students) {
            $file = fopen('php://output', 'w');
            // BOM for Excel Arabic
            fprintf($file, chr(0xEF) . chr(0xBB) . chr(0xBF));
            fputcsv($file, ['رقم الطالب', 'الاسم الأول', 'اللقب', 'الجنس', 'الهاتف', 'ولي الأمر', 'المستوى', 'الحالة', 'تاريخ التسجيل']);
            foreach ($students as $s) {
                fputcsv($file, [
                    $s->student_number, $s->first_name, $s->last_name,
                    $s->gender === 'male' ? 'ذكر' : 'أنثى',
                    $s->phone, $s->guardian_name, $s->educational_level,
                    $s->status, $s->enrollment_date
                ]);
            }
            fclose($file);
        };

        return response()->stream($callback, 200, $headers);
    }

    public function downloadTemplate()
    {
        $headers = [
            'Content-Type' => 'text/csv; charset=UTF-8',
            'Content-Disposition' => 'attachment; filename=students_template.csv',
        ];
        $callback = function () {
            $file = fopen('php://output', 'w');
            fprintf($file, chr(0xEF) . chr(0xBB) . chr(0xBF));
            fputcsv($file, ['الاسم الأول', 'اللقب', 'الجنس (male/female)', 'الهاتف', 'ولي الأمر', 'المستوى الدراسي', 'تاريخ التسجيل (YYYY-MM-DD)']);
            fputcsv($file, ['محمد', 'بن علي', 'male', '0555000000', 'أحمد بن علي', 'ابتدائي', date('Y-m-d')]);
            fclose($file);
        };
        return response()->stream($callback, 200, $headers);
    }

    public function importExcel(Request $request)
    {
        $request->validate(['file' => 'required|file|mimes:csv,txt']);
        $file = $request->file('file');
        $handle = fopen($file->getPathname(), 'r');
        $header = fgetcsv($handle); // skip header row
        $count = 0;
        while (($row = fgetcsv($handle)) !== false) {
            if (empty($row[0])) continue;
            $lastId = DB::table('students')->max('id') ?? 0;
            $studentNumber = 'FD' . str_pad($lastId + 1, 4, '0', STR_PAD_LEFT);
            DB::table('students')->insert([
                'student_number'    => $studentNumber,
                'first_name'        => $row[0] ?? '',
                'last_name'         => $row[1] ?? '',
                'gender'            => $row[2] ?? null,
                'phone'             => $row[3] ?? null,
                'guardian_name'     => $row[4] ?? null,
                'educational_level' => $row[5] ?? null,
                'enrollment_date'   => !empty($row[6]) ? $row[6] : now()->toDateString(),
                'status'            => 'waiting',
                'created_at'        => now(),
                'updated_at'        => now(),
            ]);
            $count++;
        }
        fclose($handle);
        return redirect()->route('students.index')->with('success', "تم استيراد $count طالب بنجاح");
    }
}
