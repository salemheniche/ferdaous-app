<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SubjectController extends Controller
{
    public function index()
    {
        $subjects = DB::table('subjects')->orderByDesc('id')->get();
        return view('subjects.index', compact('subjects'));
    }

    public function store(Request $request)
    {
        $request->validate(['name' => 'required|string|max:100']);
        DB::table('subjects')->insert([
            'name'            => $request->name,
            'subject_code'    => $request->subject_code,
            'description'     => $request->description,
            'weekly_sessions' => $request->weekly_sessions ?? 1,
            'created_at'      => now(), 'updated_at' => now(),
        ]);
        return redirect()->route('subjects.index')->with('success', 'تم إضافة المادة');
    }

    public function edit($id)
    {
        $subject = DB::table('subjects')->where('id', $id)->first();
        return view('subjects.edit', compact('subject'));
    }

    public function update(Request $request, $id)
    {
        DB::table('subjects')->where('id', $id)->update([
            'name'            => $request->name,
            'subject_code'    => $request->subject_code,
            'description'     => $request->description,
            'weekly_sessions' => $request->weekly_sessions ?? 1,
            'updated_at'      => now(),
        ]);
        return redirect()->route('subjects.index')->with('success', 'تم التحديث');
    }

    public function destroy($id)
    {
        DB::table('subjects')->where('id', $id)->delete();
        return redirect()->route('subjects.index')->with('success', 'تم الحذف');
    }
}
