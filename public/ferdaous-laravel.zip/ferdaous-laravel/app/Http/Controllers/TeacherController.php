<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TeacherController extends Controller
{
    public function index()
    {
        $teachers = DB::table('teachers')
            ->leftJoin('users', 'users.teacher_id', '=', 'teachers.id')
            ->select('teachers.*', 'users.username as user_username', 'users.status as user_status')
            ->orderByDesc('teachers.id')
            ->get();

        $groups = DB::table('groups')->orderBy('name')->get();
        return view('teachers.index', compact('teachers', 'groups'));
    }

    public function store(Request $request)
    {
        $request->validate(['full_name' => 'required|string|max:150']);

        $lastId = DB::table('teachers')->max('id') ?? 0;
        $teacherNumber = 'T' . str_pad($lastId + 1, 4, '0', STR_PAD_LEFT);

        $teacherId = DB::table('teachers')->insertGetId([
            'teacher_number' => $teacherNumber,
            'full_name'      => $request->full_name,
            'phone'          => $request->phone,
            'qualification'  => $request->qualification,
            'email'          => $request->email,
            'hire_date'      => $request->hire_date,
            'base_salary'    => $request->base_salary,
            'status'         => $request->status ?? 'active',
            'created_at'     => now(),
            'updated_at'     => now(),
        ]);

        // Create user account if requested
        if ($request->boolean('create_user') && $request->user_password) {
            $username = $request->phone ?? 'teacher_' . $teacherId;
            DB::table('users')->insert([
                'role'       => 'teacher',
                'username'   => $username,
                'password'   => hash('sha256', $request->user_password),
                'full_name'  => $request->full_name,
                'phone'      => $request->phone,
                'teacher_id' => $teacherId,
                'status'     => 'active',
                'created_at' => now(),
                'updated_at' => now(),
            ]);
            DB::table('teachers')->where('id', $teacherId)->update(['user_id' => DB::getPdo()->lastInsertId()]);
        }

        return redirect()->route('teachers.index')->with('success', 'تم إضافة المعلم بنجاح');
    }

    public function edit($id)
    {
        $teacher = DB::table('teachers')->where('id', $id)->first();
        abort_if(!$teacher, 404);
        return view('teachers.edit', compact('teacher'));
    }

    public function update(Request $request, $id)
    {
        DB::table('teachers')->where('id', $id)->update([
            'full_name'     => $request->full_name,
            'phone'         => $request->phone,
            'qualification' => $request->qualification,
            'email'         => $request->email,
            'hire_date'     => $request->hire_date,
            'base_salary'   => $request->base_salary,
            'status'        => $request->status ?? 'active',
            'updated_at'    => now(),
        ]);
        return redirect()->route('teachers.index')->with('success', 'تم تحديث بيانات المعلم');
    }

    public function destroy($id)
    {
        DB::table('teachers')->where('id', $id)->delete();
        return redirect()->route('teachers.index')->with('success', 'تم حذف المعلم');
    }

    public function assignGroups(Request $request, $id)
    {
        DB::table('teacher_groups')->where('teacher_id', $id)->delete();
        foreach ($request->input('group_ids', []) as $groupId) {
            DB::table('teacher_groups')->insert([
                'teacher_id' => $id,
                'group_id'   => $groupId,
            ]);
        }
        return redirect()->route('teachers.index')->with('success', 'تم تحديث الأفواج المسندة');
    }
}
