<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    public function index()
    {
        $users = DB::table('users')->orderByDesc('id')->get();
        return view('users.index', compact('users'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'username' => 'required|string|max:100',
            'password' => 'required|min:6',
        ]);

        $exists = DB::table('users')->where('username', $request->username)->exists();
        if ($exists) {
            return redirect()->route('users.index')->with('error', 'اسم المستخدم موجود مسبقاً');
        }

        DB::table('users')->insert([
            'role'       => $request->role ?? 'admin',
            'username'   => $request->username,
            'password'   => hash('sha256', $request->password),
            'full_name'  => $request->full_name,
            'phone'      => $request->phone,
            'status'     => $request->status ?? 'active',
            'created_at' => now(), 'updated_at' => now(),
        ]);

        return redirect()->route('users.index')->with('success', 'تم إنشاء المستخدم بنجاح');
    }

    public function update(Request $request, $id)
    {
        $data = [
            'full_name'  => $request->full_name,
            'phone'      => $request->phone,
            'role'       => $request->role,
            'status'     => $request->status,
            'updated_at' => now(),
        ];

        if ($request->filled('password')) {
            $data['password'] = hash('sha256', $request->password);
        }

        DB::table('users')->where('id', $id)->update($data);
        return redirect()->route('users.index')->with('success', 'تم تحديث المستخدم');
    }

    public function destroy($id)
    {
        $current = session('user');
        if ($current && $current['id'] == $id) {
            return redirect()->route('users.index')->with('error', 'لا يمكن حذف حسابك الحالي');
        }
        DB::table('users')->where('id', $id)->delete();
        return redirect()->route('users.index')->with('success', 'تم الحذف');
    }
}
