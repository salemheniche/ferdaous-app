<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class AuthSession
{
    public function handle(Request $request, Closure $next)
    {
        $session = session('user');
        if (!$session || empty($session['id'])) {
            return redirect()->route('login');
        }
        // Share user with all views
        view()->share('authUser', $session);
        return $next($request);
    }
}
