<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Admin user (password: admin123 — SHA-256)
        DB::table('users')->insertOrIgnore([
            'role'       => 'admin',
            'username'   => 'admin',
            'password'   => hash('sha256', 'admin123'),
            'full_name'  => 'المدير',
            'status'     => 'active',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Default settings
        $settings = [
            ['key' => 'school_name',        'value' => 'مؤسسة الفردوس للتعليم القرآني فرع الديبيلة'],
            ['key' => 'academic_year',      'value' => '2025/2026'],
            ['key' => 'primary_color',      'value' => '#1a5c35'],
            ['key' => 'country_code',       'value' => '+213'],
            ['key' => 'default_fee',        'value' => '500'],
            ['key' => 'default_salary',     'value' => '15000'],
            ['key' => 'absent_message',     'value' => 'غياب الطالب {student_name} بتاريخ {date}'],
            ['key' => 'late_message',       'value' => 'تأخر الطالب {student_name} بتاريخ {date}'],
            ['key' => 'auto_attendance',    'value' => '0'],
        ];

        foreach ($settings as $s) {
            DB::table('settings')->insertOrIgnore($s);
        }
    }
}
