@extends('layouts.app')
@section('title', 'التواصل مع الأولياء')
@section('page-title', 'التواصل مع أولياء الأمور')

@section('content')
<form method="GET" class="card mb-4 flex gap-3 items-end">
    <div>
        <label class="text-xs font-semibold text-gray-500 mb-1 block">التاريخ</label>
        <input type="date" name="date" value="{{ $date }}" class="border border-gray-300 rounded-lg px-3 py-2 text-sm">
    </div>
    <button class="btn-primary text-sm">عرض الغياب</button>
    <a href="{{ route('attendance.index') }}" class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg text-sm font-semibold">رجوع</a>
</form>

@php $countryCode = $settings['country_code'] ?? '+213'; @endphp

<div class="card overflow-hidden p-0">
    <table class="w-full text-sm">
        <thead class="table-head">
            <tr>
                <th class="px-4 py-3 text-right">الطالب</th>
                <th class="px-4 py-3 text-right">الحالة</th>
                <th class="px-4 py-3 text-right">ولي الأمر</th>
                <th class="px-4 py-3 text-right">الهاتف</th>
                <th class="px-4 py-3 text-center">تواصل</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-100">
            @forelse($absent as $s)
            @php
                $phone = preg_replace('/^0/', '', $s->phone ?? '');
                $msg = $s->attendance_status === 'absent'
                    ? str_replace(['{student_name}','{date}','{time}'], [$s->first_name.' '.$s->last_name, $date, now()->format('H:i')], $settings['absent_message'] ?? '')
                    : str_replace(['{student_name}','{date}','{time}'], [$s->first_name.' '.$s->last_name, $date, now()->format('H:i')], $settings['late_message'] ?? '');
                $waLink = 'https://wa.me/' . $countryCode . $phone . '?text=' . urlencode($msg);
            @endphp
            <tr class="hover:bg-gray-50">
                <td class="px-4 py-3 font-semibold">{{ $s->first_name }} {{ $s->last_name }}</td>
                <td class="px-4 py-3">
                    <span class="{{ $s->attendance_status === 'absent' ? 'badge-withdrawn' : 'badge-waiting' }}">
                        {{ $s->attendance_status === 'absent' ? 'غائب' : 'متأخر' }}
                    </span>
                </td>
                <td class="px-4 py-3">{{ $s->guardian_name ?? '—' }}</td>
                <td class="px-4 py-3 font-mono">{{ $s->phone ?? '—' }}</td>
                <td class="px-4 py-3 flex justify-center gap-1">
                    @if($s->phone)
                    <a href="tel:{{ $s->phone }}" class="bg-green-100 hover:bg-green-200 text-green-700 px-2 py-1 rounded text-xs">📞</a>
                    <a href="{{ $waLink }}" target="_blank" class="bg-green-500 hover:bg-green-600 text-white px-2 py-1 rounded text-xs">WhatsApp</a>
                    <a href="sms:{{ $s->phone }}" class="bg-blue-100 hover:bg-blue-200 text-blue-700 px-2 py-1 rounded text-xs">SMS</a>
                    @else
                    <span class="text-gray-400 text-xs">لا يوجد هاتف</span>
                    @endif
                </td>
            </tr>
            @empty
            <tr><td colspan="5" class="text-center py-8 text-gray-400">لا يوجد غياب أو تأخر في هذا اليوم ✅</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection
