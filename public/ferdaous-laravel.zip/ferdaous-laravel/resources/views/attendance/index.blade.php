@extends('layouts.app')
@section('title', 'الحضور والغياب')
@section('page-title', 'تسجيل الحضور والغياب')

@section('content')
<form method="GET" class="card mb-4 flex flex-wrap gap-3 items-end">
    <div>
        <label class="text-xs font-semibold text-gray-500 mb-1 block">التاريخ</label>
        <input type="date" name="date" value="{{ $date }}"
               class="border border-gray-300 rounded-lg px-3 py-2 text-sm">
    </div>
    <div>
        <label class="text-xs font-semibold text-gray-500 mb-1 block">الفوج</label>
        <select name="group_id" class="border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <option value="">اختر الفوج</option>
            @foreach($groups as $g)
            <option value="{{ $g->id }}" {{ $groupId == $g->id ? 'selected':'' }}>{{ $g->name }}</option>
            @endforeach
        </select>
    </div>
    <button class="btn-primary text-sm">عرض الطلاب</button>
    <a href="{{ route('attendance.contact', ['date' => $date]) }}" class="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-lg text-sm font-semibold">
        📞 التواصل مع الأولياء
    </a>
</form>

@if($groupId && $students->isNotEmpty())
@php
$present = $students->filter(fn($s) => isset($attendances[$s->id]) && $attendances[$s->id]->status === 'present')->count();
$absent  = $students->filter(fn($s) => isset($attendances[$s->id]) && $attendances[$s->id]->status === 'absent')->count();
$late    = $students->filter(fn($s) => isset($attendances[$s->id]) && $attendances[$s->id]->status === 'late')->count();
@endphp

<div class="grid grid-cols-4 gap-3 mb-4">
    <div class="card text-center"><div class="text-2xl font-bold text-gray-700">{{ $students->count() }}</div><div class="text-xs text-gray-500">الإجمالي</div></div>
    <div class="card text-center"><div class="text-2xl font-bold text-green-600">{{ $present }}</div><div class="text-xs text-gray-500">حاضر</div></div>
    <div class="card text-center"><div class="text-2xl font-bold text-red-600">{{ $absent }}</div><div class="text-xs text-gray-500">غائب</div></div>
    <div class="card text-center"><div class="text-2xl font-bold text-yellow-600">{{ $late }}</div><div class="text-xs text-gray-500">متأخر</div></div>
</div>

<form method="POST" action="{{ route('attendance.store') }}">
    @csrf
    <input type="hidden" name="date" value="{{ $date }}">
    <div class="card overflow-hidden p-0">
        <table class="w-full text-sm">
            <thead class="table-head">
                <tr>
                    <th class="px-4 py-3 text-right">الطالب</th>
                    <th class="px-4 py-3 text-center">الحالة</th>
                    <th class="px-4 py-3 text-right">ملاحظات</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                @foreach($students as $student)
                @php $att = $attendances[$student->id] ?? null; @endphp
                <tr class="hover:bg-gray-50">
                    <td class="px-4 py-3 font-semibold">
                        {{ $student->first_name }} {{ $student->last_name }}
                        <span class="text-xs text-gray-400 font-mono mr-2">{{ $student->student_number }}</span>
                    </td>
                    <td class="px-4 py-3">
                        <div class="flex justify-center gap-1">
                            @foreach(['present'=>['حاضر','green'],'absent'=>['غائب','red'],'late'=>['متأخر','yellow'],'excused'=>['معذور','blue']] as $val=>[$label,$color])
                            <label class="cursor-pointer">
                                <input type="radio" name="records[{{ $student->id }}][status]" value="{{ $val }}"
                                       {{ ($att && $att->status === $val) || (!$att && $val === 'present') ? 'checked' : '' }}
                                       class="sr-only peer">
                                <span class="px-2 py-1 rounded text-xs font-semibold border-2 border-{{ $color }}-200 peer-checked:bg-{{ $color }}-500 peer-checked:text-white peer-checked:border-{{ $color }}-500 bg-white text-{{ $color }}-700">
                                    {{ $label }}
                                </span>
                            </label>
                            @endforeach
                        </div>
                    </td>
                    <td class="px-4 py-3">
                        <input name="records[{{ $student->id }}][notes]" value="{{ $att?->notes }}" placeholder="ملاحظة..."
                               class="w-full border border-gray-200 rounded px-2 py-1 text-xs">
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    <div class="mt-4">
        <button type="submit" class="btn-primary px-8 py-3 text-base">💾 حفظ الحضور</button>
    </div>
</form>
@elseif($groupId)
<div class="card text-center py-8 text-gray-400">لا يوجد طلاب نشطون في هذا الفوج</div>
@else
<div class="card text-center py-8 text-gray-400">اختر الفوج والتاريخ لتسجيل الحضور</div>
@endif
@endsection
