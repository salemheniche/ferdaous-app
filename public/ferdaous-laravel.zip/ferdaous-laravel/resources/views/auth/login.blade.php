<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول — منصة الفردوس</title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>* { font-family: 'Cairo', sans-serif; }</style>
</head>
<body class="min-h-screen flex items-center justify-center" style="background: linear-gradient(135deg, #1a5c35 0%, #0a2b17 50%, #1a5c35 100%);">
    <div class="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-sm">
        <div class="text-center mb-8">
            <div class="w-16 h-16 rounded-full bg-primary-700 flex items-center justify-center font-bold text-white text-2xl mx-auto mb-3"
                 style="background:#1a5c35">ف</div>
            <h1 class="text-2xl font-bold text-gray-800">منصة الفردوس</h1>
            <p class="text-gray-500 text-sm mt-1">للتعليم القرآني</p>
        </div>

        @if(session('error'))
        <div class="bg-red-50 border border-red-200 text-red-700 rounded-lg px-4 py-3 mb-4 text-sm text-center">
            {{ session('error') }}
        </div>
        @endif

        <form method="POST" action="/login" class="space-y-4">
            @csrf
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">اسم المستخدم أو الهاتف</label>
                <input type="text" name="username" required
                       class="w-full border border-gray-300 rounded-lg px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-green-500"
                       placeholder="admin" value="{{ old('username') }}">
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">كلمة المرور</label>
                <input type="password" name="password" required
                       class="w-full border border-gray-300 rounded-lg px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-green-500"
                       placeholder="••••••••">
            </div>
            <button type="submit"
                    class="w-full py-3 rounded-lg text-white font-bold text-lg mt-2 transition-all"
                    style="background:#1a5c35">
                دخول
            </button>
        </form>

        <p class="text-center text-xs text-gray-400 mt-6">
            بيانات الدخول الافتراضية: <strong>admin</strong> / <strong>admin123</strong>
        </p>
    </div>
</body>
</html>
