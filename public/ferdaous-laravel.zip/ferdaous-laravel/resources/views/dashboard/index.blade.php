@extends('layouts.app')
@section('title', 'لوحة التحكم')
@section('page-title', 'لوحة التحكم')

@section('content')
<div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
    <div class="card text-center">
        <div class="text-3xl font-bold text-primary">{{ $stats['total_students'] }}</div>
        <div class="text-gray-500 text-sm mt-1">إجمالي الطلاب</div>
    </div>
    <div class="card text-center">
        <div class="text-3xl font-bold text-green-600">{{ $stats['active_students'] }}</div>
        <div class="text-gray-500 text-sm mt-1">طلاب نشطون</div>
    </div>
    <div class="card text-center">
        <div class="text-3xl font-bold text-yellow-600">{{ $stats['waiting_students'] }}</div>
        <div class="text-gray-500 text-sm mt-1">بانتظار التسجيل</div>
    </div>
    <div class="card text-center">
        <div class="text-3xl font-bold text-red-600">{{ $stats['withdrawn_students'] }}</div>
        <div class="text-gray-500 text-sm mt-1">منسحبون</div>
    </div>
    <div class="card text-center">
        <div class="text-3xl font-bold text-blue-600">{{ $stats['graduated_students'] }}</div>
        <div class="text-gray-500 text-sm mt-1">متخرجون</div>
    </div>
    <div class="card text-center">
        <div class="text-3xl font-bold text-purple-600">{{ $stats['total_teachers'] }}</div>
        <div class="text-gray-500 text-sm mt-1">المعلمون</div>
    </div>
    <div class="card text-center">
        <div class="text-3xl font-bold text-indigo-600">{{ $stats['total_groups'] }}</div>
        <div class="text-gray-500 text-sm mt-1">الأفواج</div>
    </div>
    <div class="card text-center">
        <div class="text-3xl font-bold text-teal-600">{{ $stats['open_groups'] }}</div>
        <div class="text-gray-500 text-sm mt-1">أفواج مفتوحة</div>
    </div>
</div>

@if(count($groupsToday) > 0)
<div class="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6">
    <h3 class="font-bold text-amber-800 mb-2">⚠️ أفواج لم يُسجّل حضورها اليوم</h3>
    <div class="flex flex-wrap gap-2">
        @foreach($groupsToday as $g)
        <a href="{{ route('attendance.index', ['group_id' => $g->id, 'date' => now()->toDateString()]) }}"
           class="bg-amber-100 text-amber-800 px-3 py-1 rounded-full text-sm hover:bg-amber-200">
            {{ $g->name }}
        </a>
        @endforeach
    </div>
</div>
@else
<div class="bg-green-50 border border-green-200 rounded-xl p-4 mb-6 text-green-700 font-semibold">
    ✅ تم تسجيل الحضور لجميع الأفواج اليوم
</div>
@endif

<div class="grid grid-cols-1 md:grid-cols-3 gap-4">
    <a href="{{ route('students.create') }}" class="card flex items-center gap-4 hover:shadow-md transition-all cursor-pointer">
        <span class="text-3xl">👨‍🎓</span>
        <div><div class="font-bold text-gray-800">إضافة طالب</div><div class="text-sm text-gray-500">تسجيل طالب جديد</div></div>
    </a>
    <a href="{{ route('attendance.index') }}" class="card flex items-center gap-4 hover:shadow-md transition-all cursor-pointer">
        <span class="text-3xl">✅</span>
        <div><div class="font-bold text-gray-800">تسجيل الحضور</div><div class="text-sm text-gray-500">حضور وغياب اليوم</div></div>
    </a>
    <a href="{{ route('reports.cards') }}" class="card flex items-center gap-4 hover:shadow-md transition-all cursor-pointer">
        <span class="text-3xl">🪪</span>
        <div><div class="font-bold text-gray-800">بطاقات الطلاب</div><div class="text-sm text-gray-500">طباعة بطاقات التعريف</div></div>
    </a>
</div>
@endsection
