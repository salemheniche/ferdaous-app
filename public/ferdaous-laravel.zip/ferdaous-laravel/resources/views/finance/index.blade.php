@extends('layouts.app')
@section('title', 'المالية')
@section('page-title', 'الإدارة المالية')

@section('content')
@php $tab = request('tab', 'overview'); @endphp

{{-- Summary cards --}}
@if($tab === 'overview' || true)
<div class="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
    <div class="card text-center"><div class="text-2xl font-bold text-green-600">{{ number_format($totalIncome) }}</div><div class="text-xs text-gray-500 mt-1">إجمالي الإيرادات</div></div>
    <div class="card text-center"><div class="text-2xl font-bold text-red-600">{{ number_format($totalOutcome) }}</div><div class="text-xs text-gray-500 mt-1">إجمالي المصروفات</div></div>
    <div class="card text-center"><div class="text-2xl font-bold text-primary">{{ number_format($totalFees) }}</div><div class="text-xs text-gray-500 mt-1">رسوم الطلاب</div></div>
    <div class="card text-center"><div class="text-2xl font-bold {{ $netBalance >= 0 ? 'text-green-600' : 'text-red-600' }}">{{ number_format($netBalance) }}</div><div class="text-xs text-gray-500 mt-1">الرصيد الصافي</div></div>
</div>
@endif

{{-- Tabs --}}
<div class="flex gap-1 mb-4 bg-gray-100 p-1 rounded-xl w-fit">
    @foreach(['overview'=>'نظرة عامة','fees'=>'الرسوم','salaries'=>'الرواتب','expenses'=>'المصروفات','donations'=>'التبرعات'] as $key=>$label)
    <a href="{{ route('finance.index', ['tab'=>$key]) }}"
       class="px-4 py-2 rounded-lg text-sm font-semibold {{ $tab===$key ? 'bg-white shadow text-primary' : 'text-gray-500 hover:text-gray-700' }}">
        {{ $label }}
    </a>
    @endforeach
</div>

{{-- Fees --}}
@if($tab === 'fees')
<div class="flex gap-2 mb-3">
    <button onclick="document.getElementById('fee-modal').classList.remove('hidden')" class="btn-primary text-sm">+ إضافة دفع</button>
</div>
<div class="card overflow-hidden p-0">
    <table class="w-full text-sm">
        <thead class="table-head"><tr>
            <th class="px-4 py-3 text-right">الطالب</th><th class="px-4 py-3 text-right">المبلغ</th>
            <th class="px-4 py-3 text-right">الشهر</th><th class="px-4 py-3 text-right">التاريخ</th>
            <th class="px-4 py-3 text-center">حذف</th>
        </tr></thead>
        <tbody class="divide-y divide-gray-100">
            @forelse($fees as $f)
            <tr class="hover:bg-gray-50">
                <td class="px-4 py-3 font-semibold">{{ $f->student_name }}</td>
                <td class="px-4 py-3 font-bold text-green-600">{{ $f->amount }} دج</td>
                <td class="px-4 py-3">{{ $f->for_month ?? '—' }}</td>
                <td class="px-4 py-3 text-gray-500">{{ $f->payment_date }}</td>
                <td class="px-4 py-3 text-center">
                    <form method="POST" action="{{ route('finance.fees.destroy', $f->id) }}" onsubmit="return confirm('حذف؟')">
                        @csrf @method('DELETE') <button class="btn-danger text-xs px-2 py-1">حذف</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr><td colspan="5" class="text-center py-6 text-gray-400">لا يوجد دفعات</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
@endif

{{-- Expenses --}}
@if($tab === 'expenses')
<div class="flex gap-2 mb-3">
    <button onclick="document.getElementById('expense-modal').classList.remove('hidden')" class="btn-primary text-sm">+ إضافة مصروف</button>
</div>
<div class="card overflow-hidden p-0">
    <table class="w-full text-sm">
        <thead class="table-head"><tr>
            <th class="px-4 py-3 text-right">الفئة</th><th class="px-4 py-3 text-right">المبلغ</th>
            <th class="px-4 py-3 text-right">التاريخ</th><th class="px-4 py-3 text-right">ملاحظات</th>
            <th class="px-4 py-3 text-center">حذف</th>
        </tr></thead>
        <tbody class="divide-y divide-gray-100">
            @forelse($expenses as $e)
            <tr class="hover:bg-gray-50">
                <td class="px-4 py-3 font-semibold">{{ $e->category ?? '—' }}</td>
                <td class="px-4 py-3 font-bold text-red-600">{{ $e->amount }} دج</td>
                <td class="px-4 py-3 text-gray-500">{{ $e->expense_date }}</td>
                <td class="px-4 py-3 text-gray-500">{{ $e->notes ?? '—' }}</td>
                <td class="px-4 py-3 text-center">
                    <form method="POST" action="{{ route('finance.expenses.destroy', $e->id) }}" onsubmit="return confirm('حذف؟')">
                        @csrf @method('DELETE') <button class="btn-danger text-xs px-2 py-1">حذف</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr><td colspan="5" class="text-center py-6 text-gray-400">لا يوجد مصروفات</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
@endif

{{-- Donations --}}
@if($tab === 'donations')
<div class="flex gap-2 mb-3">
    <button onclick="document.getElementById('donation-modal').classList.remove('hidden')" class="btn-primary text-sm">+ إضافة تبرع</button>
</div>
<div class="card overflow-hidden p-0">
    <table class="w-full text-sm">
        <thead class="table-head"><tr>
            <th class="px-4 py-3 text-right">المتبرع</th><th class="px-4 py-3 text-right">المبلغ</th>
            <th class="px-4 py-3 text-right">التاريخ</th>
            <th class="px-4 py-3 text-center">حذف</th>
        </tr></thead>
        <tbody class="divide-y divide-gray-100">
            @forelse($donations as $d)
            <tr class="hover:bg-gray-50">
                <td class="px-4 py-3 font-semibold">{{ $d->donor_name ?? '—' }}</td>
                <td class="px-4 py-3 font-bold text-blue-600">{{ $d->amount }} دج</td>
                <td class="px-4 py-3 text-gray-500">{{ $d->donation_date }}</td>
                <td class="px-4 py-3 text-center">
                    <form method="POST" action="{{ route('finance.donations.destroy', $d->id) }}" onsubmit="return confirm('حذف؟')">
                        @csrf @method('DELETE') <button class="btn-danger text-xs px-2 py-1">حذف</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr><td colspan="4" class="text-center py-6 text-gray-400">لا يوجد تبرعات</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
@endif

{{-- Salaries --}}
@if($tab === 'salaries')
<div class="flex gap-2 mb-3">
    <button onclick="document.getElementById('salary-modal').classList.remove('hidden')" class="btn-primary text-sm">+ إضافة راتب</button>
</div>
<div class="card overflow-hidden p-0">
    <table class="w-full text-sm">
        <thead class="table-head"><tr>
            <th class="px-4 py-3 text-right">المعلم</th><th class="px-4 py-3 text-right">الشهر</th>
            <th class="px-4 py-3 text-right">الأساسي</th><th class="px-4 py-3 text-right">منحة</th>
            <th class="px-4 py-3 text-right">خصم</th><th class="px-4 py-3 text-right">الصافي</th>
            <th class="px-4 py-3 text-center">حذف</th>
        </tr></thead>
        <tbody class="divide-y divide-gray-100">
            @forelse($salaries as $s)
            <tr class="hover:bg-gray-50">
                <td class="px-4 py-3 font-semibold">{{ $s->teacher_name }}</td>
                <td class="px-4 py-3">{{ $s->for_month }}</td>
                <td class="px-4 py-3">{{ $s->base_salary }} دج</td>
                <td class="px-4 py-3 text-green-600">{{ $s->bonus }} دج</td>
                <td class="px-4 py-3 text-red-600">{{ $s->deduction }} دج</td>
                <td class="px-4 py-3 font-bold text-primary">{{ $s->net_salary }} دج</td>
                <td class="px-4 py-3 text-center">
                    <form method="POST" action="{{ route('finance.salaries.destroy', $s->id) }}" onsubmit="return confirm('حذف؟')">
                        @csrf @method('DELETE') <button class="btn-danger text-xs px-2 py-1">حذف</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr><td colspan="7" class="text-center py-6 text-gray-400">لا يوجد رواتب</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
@endif

{{-- Modals --}}
<div id="fee-modal" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
    <div class="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-md">
        <div class="flex justify-between mb-4"><h3 class="font-bold">إضافة دفعة</h3><button onclick="document.getElementById('fee-modal').classList.add('hidden')" class="text-gray-400 text-2xl">×</button></div>
        <form method="POST" action="{{ route('finance.fees.store') }}" class="space-y-3">
            @csrf
            <select name="student_id" required class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
                <option value="">اختر الطالب *</option>
                @foreach($students as $s)<option value="{{ $s->id }}">{{ $s->first_name }} {{ $s->last_name }}</option>@endforeach
            </select>
            <input name="amount" required placeholder="المبلغ *" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <input name="for_month" placeholder="الشهر (مثال: 2025-01)" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <input type="date" name="payment_date" value="{{ date('Y-m-d') }}" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <div class="flex gap-2"><button type="submit" class="btn-primary flex-1">حفظ</button><button type="button" onclick="document.getElementById('fee-modal').classList.add('hidden')" class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg flex-1">إلغاء</button></div>
        </form>
    </div>
</div>

<div id="expense-modal" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
    <div class="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-md">
        <div class="flex justify-between mb-4"><h3 class="font-bold">إضافة مصروف</h3><button onclick="document.getElementById('expense-modal').classList.add('hidden')" class="text-gray-400 text-2xl">×</button></div>
        <form method="POST" action="{{ route('finance.expenses.store') }}" class="space-y-3">
            @csrf
            <input name="category" required placeholder="الفئة *" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <input name="amount" required placeholder="المبلغ *" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <input type="date" name="expense_date" value="{{ date('Y-m-d') }}" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <textarea name="notes" placeholder="ملاحظات" rows="2" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm"></textarea>
            <div class="flex gap-2"><button type="submit" class="btn-primary flex-1">حفظ</button><button type="button" onclick="document.getElementById('expense-modal').classList.add('hidden')" class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg flex-1">إلغاء</button></div>
        </form>
    </div>
</div>

<div id="donation-modal" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
    <div class="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-md">
        <div class="flex justify-between mb-4"><h3 class="font-bold">إضافة تبرع</h3><button onclick="document.getElementById('donation-modal').classList.add('hidden')" class="text-gray-400 text-2xl">×</button></div>
        <form method="POST" action="{{ route('finance.donations.store') }}" class="space-y-3">
            @csrf
            <input name="donor_name" required placeholder="اسم المتبرع *" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <input name="amount" required placeholder="المبلغ *" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <input type="date" name="donation_date" value="{{ date('Y-m-d') }}" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <div class="flex gap-2"><button type="submit" class="btn-primary flex-1">حفظ</button><button type="button" onclick="document.getElementById('donation-modal').classList.add('hidden')" class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg flex-1">إلغاء</button></div>
        </form>
    </div>
</div>

<div id="salary-modal" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
    <div class="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-md">
        <div class="flex justify-between mb-4"><h3 class="font-bold">إضافة راتب</h3><button onclick="document.getElementById('salary-modal').classList.add('hidden')" class="text-gray-400 text-2xl">×</button></div>
        <form method="POST" action="{{ route('finance.salaries.store') }}" class="space-y-3">
            @csrf
            <select name="teacher_id" required class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
                <option value="">اختر المعلم *</option>
                @foreach($teachers as $t)<option value="{{ $t->id }}">{{ $t->full_name }}</option>@endforeach
            </select>
            <input name="for_month" required placeholder="الشهر (مثال: 2025-01)" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <input name="base_salary" required placeholder="الراتب الأساسي *" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <input name="bonus" placeholder="منحة" value="0" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <input name="deduction" placeholder="خصم" value="0" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <input type="date" name="payment_date" value="{{ date('Y-m-d') }}" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <div class="flex gap-2"><button type="submit" class="btn-primary flex-1">حفظ</button><button type="button" onclick="document.getElementById('salary-modal').classList.add('hidden')" class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg flex-1">إلغاء</button></div>
        </form>
    </div>
</div>
@endsection
