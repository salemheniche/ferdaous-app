@extends('layouts.app')
@section('title', 'تعديل الفوج')
@section('page-title', 'تعديل الفوج')
@section('content')
<div class="max-w-md">
    <form method="POST" action="{{ route('groups.update', $group->id) }}" class="card space-y-3">
        @csrf @method('PUT')
        <input name="name" required value="{{ $group->name }}" placeholder="الاسم *" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
        <input name="group_type" value="{{ $group->group_type }}" placeholder="النوع" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
        <input name="capacity" type="number" value="{{ $group->capacity }}" placeholder="الطاقة" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
        <select name="room_id" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <option value="">بدون قاعة</option>
            @foreach($rooms as $r)<option value="{{ $r->id }}" {{ $group->room_id==$r->id ? 'selected':'' }}>{{ $r->name }}</option>@endforeach
        </select>
        <select name="status" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <option value="open"   {{ $group->status==='open'   ? 'selected':'' }}>مفتوح</option>
            <option value="closed" {{ $group->status==='closed' ? 'selected':'' }}>مغلق</option>
        </select>
        <div class="flex gap-2"><button type="submit" class="btn-primary">حفظ</button><a href="{{ route('groups.index') }}" class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg font-semibold">إلغاء</a></div>
    </form>
</div>
@endsection
