@extends('layouts.app')
@section('title', 'الأفواج')
@section('page-title', 'إدارة الأفواج')

@section('content')
<div class="flex gap-2 mb-4">
    <button onclick="document.getElementById('add-modal').classList.remove('hidden')" class="btn-primary">+ إضافة فوج</button>
</div>

<div class="card overflow-hidden p-0">
    <table class="w-full text-sm">
        <thead class="table-head">
            <tr>
                <th class="px-4 py-3 text-right">رقم الفوج</th>
                <th class="px-4 py-3 text-right">الاسم</th>
                <th class="px-4 py-3 text-right">النوع</th>
                <th class="px-4 py-3 text-right">الطاقة</th>
                <th class="px-4 py-3 text-right">الطلاب</th>
                <th class="px-4 py-3 text-right">الحالة</th>
                <th class="px-4 py-3 text-center">إجراءات</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-100">
            @forelse($groups as $g)
            <tr class="hover:bg-gray-50">
                <td class="px-4 py-3 font-mono text-primary font-semibold">{{ $g->group_number }}</td>
                <td class="px-4 py-3 font-semibold">{{ $g->name }}</td>
                <td class="px-4 py-3">{{ $g->group_type ?? '—' }}</td>
                <td class="px-4 py-3">{{ $g->capacity ?? '—' }}</td>
                <td class="px-4 py-3">
                    <span class="bg-blue-100 text-blue-700 text-xs px-2 py-0.5 rounded-full">{{ $g->student_count }}</span>
                </td>
                <td class="px-4 py-3">
                    <span class="{{ $g->status === 'open' ? 'badge-active' : 'badge-withdrawn' }}">
                        {{ $g->status === 'open' ? 'مفتوح' : 'مغلق' }}
                    </span>
                </td>
                <td class="px-4 py-3 flex justify-center gap-1">
                    <a href="{{ route('groups.show', $g->id) }}" class="bg-gray-100 hover:bg-gray-200 text-gray-700 px-2 py-1 rounded text-xs">الطلاب</a>
                    <a href="{{ route('groups.edit', $g->id) }}" class="btn-edit text-xs px-2 py-1">تعديل</a>
                    <form method="POST" action="{{ route('groups.destroy', $g->id) }}" onsubmit="return confirm('حذف الفوج؟')">
                        @csrf @method('DELETE')
                        <button class="btn-danger text-xs px-2 py-1">حذف</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr><td colspan="7" class="text-center py-8 text-gray-400">لا يوجد أفواج</td></tr>
            @endforelse
        </tbody>
    </table>
</div>

{{-- Add Modal --}}
<div id="add-modal" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
    <div class="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-md">
        <div class="flex justify-between items-center mb-4">
            <h3 class="font-bold text-lg">إضافة فوج</h3>
            <button onclick="document.getElementById('add-modal').classList.add('hidden')" class="text-gray-400 text-2xl">×</button>
        </div>
        <form method="POST" action="{{ route('groups.store') }}" class="space-y-3">
            @csrf
            <input name="name" required placeholder="اسم الفوج *" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <input name="group_type" placeholder="نوع الفوج (حفظ / تجويد ...)" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <input name="capacity" type="number" placeholder="الطاقة الاستيعابية" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <select name="room_id" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
                <option value="">اختر القاعة (اختياري)</option>
                @foreach($rooms as $r)
                <option value="{{ $r->id }}">{{ $r->name }}</option>
                @endforeach
            </select>
            <div class="flex gap-2 pt-2">
                <button type="submit" class="btn-primary flex-1">حفظ</button>
                <button type="button" onclick="document.getElementById('add-modal').classList.add('hidden')"
                        class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg flex-1">إلغاء</button>
            </div>
        </form>
    </div>
</div>
@endsection
