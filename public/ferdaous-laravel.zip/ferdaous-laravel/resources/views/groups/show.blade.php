@extends('layouts.app')
@section('title', 'طلاب الفوج')
@section('page-title', 'طلاب فوج: {{ $group->name }}')

@section('content')
<div class="flex gap-2 mb-4">
    <a href="{{ route('groups.index') }}" class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg text-sm font-semibold">← رجوع</a>
</div>

<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
    {{-- Students list --}}
    <div class="card overflow-hidden p-0">
        <div class="px-4 py-3 bg-gray-50 font-bold text-gray-700 border-b">طلاب الفوج ({{ $students->count() }})</div>
        <table class="w-full text-sm">
            <tbody class="divide-y divide-gray-100">
                @forelse($students as $s)
                <tr class="hover:bg-gray-50">
                    <td class="px-4 py-3">
                        <span class="font-semibold">{{ $s->first_name }} {{ $s->last_name }}</span>
                        <span class="text-xs text-gray-400 mr-1">{{ $s->student_number }}</span>
                    </td>
                    <td class="px-4 py-3 text-left">
                        <form method="POST" action="{{ route('groups.removeStudent', [$group->id, $s->id]) }}"
                              onsubmit="return confirm('إزالة الطالب من الفوج؟')">
                            @csrf @method('DELETE')
                            <button class="btn-danger text-xs px-2 py-1">إزالة</button>
                        </form>
                    </td>
                </tr>
                @empty
                <tr><td class="text-center py-6 text-gray-400">لا يوجد طلاب</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>

    {{-- Add student --}}
    <div class="card">
        <h3 class="font-bold text-gray-700 mb-3">إضافة طالب للفوج</h3>
        <form method="POST" action="{{ route('groups.addStudent', $group->id) }}" class="space-y-3">
            @csrf
            <select name="student_id" required class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
                <option value="">اختر الطالب</option>
                @foreach($allStudents as $s)
                <option value="{{ $s->id }}">{{ $s->first_name }} {{ $s->last_name }} — {{ $s->student_number }}</option>
                @endforeach
            </select>
            <button type="submit" class="btn-primary w-full">إضافة للفوج</button>
        </form>
    </div>
</div>
@endsection
