<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'منصة الفردوس') — مؤسسة الفردوس للتعليم القرآني</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { cairo: ['Cairo', 'sans-serif'] },
                    colors: {
                        primary: { DEFAULT:'#1a5c35', dark:'#0a2b17', light:'#2d8a52' }
                    }
                }
            }
        }
    </script>
    <style>
        * { font-family: 'Cairo', sans-serif; }
        .sidebar-link { @apply flex items-center gap-3 px-4 py-2.5 rounded-lg text-green-100 hover:bg-white/10 transition-all; }
        .sidebar-link.active { @apply bg-amber-400/20 text-amber-300 border-r-4 border-amber-400; }
        .btn-primary { @apply bg-primary hover:bg-primary-light text-white px-4 py-2 rounded-lg font-semibold transition-all; }
        .btn-danger  { @apply bg-red-600 hover:bg-red-700 text-white px-3 py-1.5 rounded-lg text-sm transition-all; }
        .btn-edit    { @apply bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded-lg text-sm transition-all; }
        .card        { @apply bg-white rounded-xl shadow-sm border border-gray-100 p-5; }
        .table-head  { @apply bg-gray-50 text-gray-600 text-sm font-semibold; }
        .badge-active    { @apply bg-green-100 text-green-700 text-xs px-2 py-0.5 rounded-full; }
        .badge-waiting   { @apply bg-yellow-100 text-yellow-700 text-xs px-2 py-0.5 rounded-full; }
        .badge-withdrawn { @apply bg-red-100 text-red-700 text-xs px-2 py-0.5 rounded-full; }
        .badge-graduated { @apply bg-blue-100 text-blue-700 text-xs px-2 py-0.5 rounded-full; }
        .toast { position: fixed; top: 1rem; left: 50%; transform: translateX(-50%); z-index: 9999; min-width: 300px; padding: 1rem 1.5rem; border-radius: 0.75rem; font-weight: 600; text-align: center; }
        .toast-success { background: #d1fae5; color: #065f46; border: 1px solid #6ee7b7; }
        .toast-error   { background: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }
    </style>
    @stack('styles')
</head>
<body class="bg-gray-50 text-gray-800">

{{-- Toast notifications --}}
@if(session('success'))
<div class="toast toast-success" id="toast">{{ session('success') }}</div>
@endif
@if(session('error'))
<div class="toast toast-error" id="toast">{{ session('error') }}</div>
@endif

<div class="flex min-h-screen">

    {{-- Sidebar --}}
    <aside class="w-60 flex-shrink-0 fixed top-0 right-0 h-full z-40 flex flex-col"
           style="background: linear-gradient(180deg, #1a5c35 0%, #0a2b17 100%);">

        {{-- Logo --}}
        <div class="px-5 py-5 border-b border-white/10">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-full bg-amber-400 flex items-center justify-center font-bold text-primary text-lg">ف</div>
                <div>
                    <div class="text-white font-bold text-sm leading-tight">منصة الفردوس</div>
                    <div class="text-green-300 text-xs">للتعليم القرآني</div>
                </div>
            </div>
        </div>

        {{-- Navigation --}}
        <nav class="flex-1 overflow-y-auto px-3 py-4 space-y-1">
            <a href="{{ route('dashboard') }}" class="sidebar-link {{ request()->routeIs('dashboard') ? 'active' : '' }}">
                <span>🏠</span> لوحة التحكم
            </a>
            <a href="{{ route('students.index') }}" class="sidebar-link {{ request()->routeIs('students.*') ? 'active' : '' }}">
                <span>👨‍🎓</span> الطلاب
            </a>
            <a href="{{ route('teachers.index') }}" class="sidebar-link {{ request()->routeIs('teachers.*') ? 'active' : '' }}">
                <span>👨‍🏫</span> المعلمون
            </a>
            <a href="{{ route('groups.index') }}" class="sidebar-link {{ request()->routeIs('groups.*') ? 'active' : '' }}">
                <span>👥</span> الأفواج
            </a>
            <a href="{{ route('attendance.index') }}" class="sidebar-link {{ request()->routeIs('attendance.*') ? 'active' : '' }}">
                <span>✅</span> الحضور والغياب
            </a>
            <a href="{{ route('schedules.index') }}" class="sidebar-link {{ request()->routeIs('schedules.*') ? 'active' : '' }}">
                <span>📅</span> الجداول الدراسية
            </a>
            <a href="{{ route('subjects.index') }}" class="sidebar-link {{ request()->routeIs('subjects.*') ? 'active' : '' }}">
                <span>📚</span> المواد
            </a>
            <a href="{{ route('rooms.index') }}" class="sidebar-link {{ request()->routeIs('rooms.*') ? 'active' : '' }}">
                <span>🏫</span> القاعات
            </a>
            <a href="{{ route('finance.index') }}" class="sidebar-link {{ request()->routeIs('finance.*') ? 'active' : '' }}">
                <span>💰</span> المالية
            </a>
            <a href="{{ route('reports.index') }}" class="sidebar-link {{ request()->routeIs('reports.*') ? 'active' : '' }}">
                <span>📊</span> التقارير
            </a>
            @if(isset($authUser) && $authUser['role'] === 'admin')
            <a href="{{ route('users.index') }}" class="sidebar-link {{ request()->routeIs('users.*') ? 'active' : '' }}">
                <span>👤</span> المستخدمون
            </a>
            <a href="{{ route('settings.index') }}" class="sidebar-link {{ request()->routeIs('settings.*') ? 'active' : '' }}">
                <span>⚙️</span> الإعدادات
            </a>
            <a href="{{ route('backup.index') }}" class="sidebar-link {{ request()->routeIs('backup.*') ? 'active' : '' }}">
                <span>💾</span> النسخ الاحتياطي
            </a>
            @endif
        </nav>

        {{-- User info + Logout --}}
        <div class="px-4 py-4 border-t border-white/10">
            <div class="text-green-200 text-sm mb-2">
                <span>👤</span> {{ $authUser['full_name'] ?? $authUser['username'] }}
                <span class="text-xs text-green-400 mr-1">({{ $authUser['role'] === 'admin' ? 'مدير' : 'معلم' }})</span>
            </div>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button class="w-full bg-red-600/80 hover:bg-red-600 text-white text-sm py-1.5 rounded-lg transition-all">
                    تسجيل الخروج
                </button>
            </form>
        </div>
    </aside>

    {{-- Main content --}}
    <main class="flex-1 mr-60 min-h-screen">
        <header class="bg-white border-b border-gray-200 px-6 py-4 sticky top-0 z-30">
            <h1 class="text-xl font-bold text-gray-800">@yield('page-title', 'لوحة التحكم')</h1>
        </header>
        <div class="p-6">
            @yield('content')
        </div>
    </main>
</div>

<script>
// Auto-hide toast after 3 seconds
setTimeout(() => {
    const t = document.getElementById('toast');
    if (t) t.style.display = 'none';
}, 3000);
</script>
@stack('scripts')
</body>
</html>
