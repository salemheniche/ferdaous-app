@extends('layouts.app')
@section('title', 'بطاقات التعريف')
@section('page-title', 'بطاقات التعريف')

@section('content')
@push('styles')
<style>
.id-card { width: 85.6mm; height: 53.98mm; border-radius: 8px; overflow: hidden; position: relative; display: inline-block; margin: 4px; }
@media print {
    .no-print { display: none !important; }
    .id-card { page-break-inside: avoid; }
}
</style>
@endpush

<div class="no-print card mb-4">
    <form method="GET" class="flex flex-wrap gap-3 items-end">
        <div>
            <label class="text-xs font-semibold text-gray-500 mb-1 block">الفوج</label>
            <select name="group_id" class="border border-gray-300 rounded-lg px-3 py-2 text-sm">
                <option value="">اختر الفوج</option>
                @foreach($groups as $g)<option value="{{ $g->id }}" {{ $groupId==$g->id ? 'selected':'' }}>{{ $g->name }}</option>@endforeach
            </select>
        </div>
        <div>
            <label class="text-xs font-semibold text-gray-500 mb-1 block">اللون</label>
            <select name="theme" class="border border-gray-300 rounded-lg px-3 py-2 text-sm">
                @foreach(['green'=>'أخضر','blue'=>'أزرق','gold'=>'ذهبي','indigo'=>'نيلي','teal'=>'فيروزي'] as $k=>$v)
                <option value="{{ $k }}" {{ $theme===$k ? 'selected':'' }}>{{ $v }}</option>
                @endforeach
            </select>
        </div>
        <button class="btn-primary text-sm">عرض</button>
        @if($students->isNotEmpty())
        <button type="button" onclick="window.print()" class="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg text-sm font-semibold">🖨️ طباعة</button>
        @endif
    </form>
</div>

@php
$colors = [
    'green'  => ['bg'=>'#1a5c35','accent'=>'#2d8a52','text'=>'#ffffff'],
    'blue'   => ['bg'=>'#1e3a8a','accent'=>'#3b82f6','text'=>'#ffffff'],
    'gold'   => ['bg'=>'#92400e','accent'=>'#f59e0b','text'=>'#ffffff'],
    'indigo' => ['bg'=>'#312e81','accent'=>'#6366f1','text'=>'#ffffff'],
    'teal'   => ['bg'=>'#134e4a','accent'=>'#14b8a6','text'=>'#ffffff'],
];
$c = $colors[$theme] ?? $colors['green'];
$schoolName = $settings['school_name'] ?? 'مؤسسة الفردوس';
$academicYear = $settings['academic_year'] ?? '2025/2026';
@endphp

@if($students->isNotEmpty())
<div style="background:#f9fafb; padding:16px; border-radius:12px;">
    @foreach($students as $student)
    <div class="id-card" style="background:{{ $c['bg'] }}; font-family:'Cairo',sans-serif; direction:rtl; color:{{ $c['text'] }}; box-shadow:0 4px 12px rgba(0,0,0,0.2);">
        {{-- Header --}}
        <div style="background:{{ $c['accent'] }}; padding:6px 10px; display:flex; align-items:center; gap:6px;">
            <div style="width:22px;height:22px;border-radius:50%;background:rgba(255,255,255,0.3);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:11px;">ف</div>
            <div style="font-size:9px;font-weight:700;line-height:1.2;">{{ $schoolName }}</div>
        </div>
        {{-- Body --}}
        <div style="padding:6px 10px;">
            <div style="font-size:13px;font-weight:700;margin-bottom:2px;">{{ $student->first_name }} {{ $student->last_name }}</div>
            <div style="font-size:9px;opacity:0.8;margin-bottom:4px;font-family:monospace;">{{ $student->student_number }}</div>
            @if($student->educational_level)
            <div style="font-size:9px;background:rgba(255,255,255,0.15);display:inline-block;padding:1px 6px;border-radius:4px;">{{ $student->educational_level }}</div>
            @endif
            @if($showGroup && isset($student->group_name))
            <div style="font-size:9px;margin-top:2px;opacity:0.9;">الفوج: {{ $student->group_name }}</div>
            @endif
        </div>
        {{-- Footer --}}
        <div style="position:absolute;bottom:0;left:0;right:0;background:{{ $c['accent'] }};padding:3px 10px;display:flex;justify-content:space-between;align-items:center;">
            <span style="font-size:8px;opacity:0.8;">{{ $showYear ? $academicYear : '' }}</span>
            <span style="font-size:8px;opacity:0.8;">بطاقة تعريف</span>
        </div>
    </div>
    @endforeach
</div>
@else
<div class="card text-center py-8 text-gray-400">اختر الفوج لعرض بطاقات الطلاب</div>
@endif
@endsection
