@extends('layouts.app')
@section('title', 'التقارير')
@section('page-title', 'التقارير')

@section('content')
<div class="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
    <div class="card text-center"><div class="text-2xl font-bold text-primary">{{ $stats['total_students'] }}</div><div class="text-xs text-gray-500">إجمالي الطلاب</div></div>
    <div class="card text-center"><div class="text-2xl font-bold text-green-600">{{ $stats['active_students'] }}</div><div class="text-xs text-gray-500">نشطون</div></div>
    <div class="card text-center"><div class="text-2xl font-bold text-purple-600">{{ $stats['total_teachers'] }}</div><div class="text-xs text-gray-500">معلمون</div></div>
    <div class="card text-center"><div class="text-2xl font-bold text-indigo-600">{{ $stats['total_groups'] }}</div><div class="text-xs text-gray-500">الأفواج</div></div>
</div>

<div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
    <div class="card">
        <h3 class="font-bold text-gray-700 mb-3">ملخص مالي</h3>
        <div class="space-y-2 text-sm">
            <div class="flex justify-between"><span class="text-gray-500">رسوم الطلاب</span><span class="font-bold text-green-600">{{ number_format($totalFees) }} دج</span></div>
            <div class="flex justify-between"><span class="text-gray-500">التبرعات</span><span class="font-bold text-blue-600">{{ number_format($totalDonations) }} دج</span></div>
            <div class="flex justify-between"><span class="text-gray-500">المصروفات</span><span class="font-bold text-red-600">{{ number_format($totalExpenses) }} دج</span></div>
            <div class="flex justify-between"><span class="text-gray-500">الرواتب</span><span class="font-bold text-orange-600">{{ number_format($totalSalaries) }} دج</span></div>
            <div class="border-t pt-2 flex justify-between font-bold">
                <span>الرصيد الصافي</span>
                <span class="{{ ($totalFees + $totalDonations - $totalExpenses - $totalSalaries) >= 0 ? 'text-green-600' : 'text-red-600' }}">
                    {{ number_format($totalFees + $totalDonations - $totalExpenses - $totalSalaries) }} دج
                </span>
            </div>
        </div>
    </div>

    <div class="card">
        <h3 class="font-bold text-gray-700 mb-3">إجراءات سريعة</h3>
        <div class="space-y-2">
            <a href="{{ route('reports.cards') }}" class="flex items-center gap-3 p-3 rounded-lg bg-green-50 hover:bg-green-100 transition-all">
                <span class="text-2xl">🪪</span>
                <div><div class="font-semibold text-sm">بطاقات التعريف</div><div class="text-xs text-gray-500">طباعة بطاقات الطلاب</div></div>
            </a>
            <a href="{{ route('students.export') }}" class="flex items-center gap-3 p-3 rounded-lg bg-blue-50 hover:bg-blue-100 transition-all">
                <span class="text-2xl">📥</span>
                <div><div class="font-semibold text-sm">تصدير بيانات الطلاب</div><div class="text-xs text-gray-500">ملف CSV/Excel</div></div>
            </a>
            <a href="{{ route('backup.download') }}" class="flex items-center gap-3 p-3 rounded-lg bg-purple-50 hover:bg-purple-100 transition-all">
                <span class="text-2xl">💾</span>
                <div><div class="font-semibold text-sm">نسخ احتياطي كامل</div><div class="text-xs text-gray-500">تنزيل ملف JSON</div></div>
            </a>
        </div>
    </div>
</div>

{{-- Group list print --}}
<div class="card">
    <h3 class="font-bold text-gray-700 mb-3">كشف حضور الفوج (للطباعة)</h3>
    <form method="GET" action="{{ route('reports.index') }}" class="flex gap-3 items-end">
        <select name="print_group" class="border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <option value="">اختر الفوج</option>
            @foreach($groups as $g)<option value="{{ $g->id }}" {{ request('print_group')==$g->id ? 'selected':'' }}>{{ $g->name }}</option>@endforeach
        </select>
        <button class="btn-primary text-sm">عرض</button>
    </form>

    @if(request('print_group'))
    @php
        $pgStudents = \Illuminate\Support\Facades\DB::table('group_students')
            ->join('students','students.id','=','group_students.student_id')
            ->where('group_students.group_id', request('print_group'))
            ->select('students.*')->get();
        $pgGroup = \Illuminate\Support\Facades\DB::table('groups')->where('id', request('print_group'))->first();
    @endphp
    <div class="mt-4 overflow-x-auto">
        <div class="text-right mb-2">
            <button onclick="window.print()" class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-1.5 rounded-lg text-sm">🖨️ طباعة</button>
        </div>
        <table class="w-full text-sm border border-gray-300">
            <thead class="bg-primary text-white">
                <tr>
                    <th class="px-3 py-2 text-right border border-gray-300">#</th>
                    <th class="px-3 py-2 text-right border border-gray-300">الطالب</th>
                    @for($i=1;$i<=6;$i++)<th class="px-3 py-2 text-center border border-gray-300">{{ $i }}</th>@endfor
                </tr>
            </thead>
            <tbody>
                @foreach($pgStudents as $i=>$s)
                <tr class="{{ $i%2===0 ? 'bg-white' : 'bg-gray-50' }}">
                    <td class="px-3 py-2 border border-gray-200">{{ $i+1 }}</td>
                    <td class="px-3 py-2 border border-gray-200 font-semibold">{{ $s->first_name }} {{ $s->last_name }}</td>
                    @for($j=1;$j<=6;$j++)<td class="px-3 py-2 border border-gray-200 text-center w-12"></td>@endfor
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    @endif
</div>
@endsection
