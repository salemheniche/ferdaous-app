@extends('layouts.app')
@section('title', 'تعديل القاعة')
@section('page-title', 'تعديل القاعة')
@section('content')
<div class="max-w-md">
    <form method="POST" action="{{ route('rooms.update', $room->id) }}" class="card space-y-3">
        @csrf @method('PUT')
        <input name="name" required value="{{ $room->name }}" placeholder="الاسم *" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
        <input name="room_number" value="{{ $room->room_number }}" placeholder="الرقم" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
        <input name="floor" value="{{ $room->floor }}" placeholder="الطابق" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
        <input name="capacity" type="number" value="{{ $room->capacity }}" placeholder="الطاقة" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
        <select name="status" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <option value="available" {{ $room->status==='available' ? 'selected':'' }}>متاحة</option>
            <option value="occupied"  {{ $room->status==='occupied'  ? 'selected':'' }}>مشغولة</option>
            <option value="maintenance" {{ $room->status==='maintenance' ? 'selected':'' }}>صيانة</option>
        </select>
        <textarea name="equipment" rows="2" placeholder="التجهيزات" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">{{ $room->equipment }}</textarea>
        <div class="flex gap-2"><button type="submit" class="btn-primary">حفظ</button><a href="{{ route('rooms.index') }}" class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg font-semibold">إلغاء</a></div>
    </form>
</div>
@endsection
