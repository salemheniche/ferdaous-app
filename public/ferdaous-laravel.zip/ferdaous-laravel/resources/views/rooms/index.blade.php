@extends('layouts.app')
@section('title', 'القاعات')
@section('page-title', 'إدارة القاعات')
@section('content')
<div class="flex gap-2 mb-4">
    <button onclick="document.getElementById('add-modal').classList.remove('hidden')" class="btn-primary">+ إضافة قاعة</button>
</div>
<div class="card overflow-hidden p-0">
    <table class="w-full text-sm">
        <thead class="table-head"><tr>
            <th class="px-4 py-3 text-right">الاسم</th>
            <th class="px-4 py-3 text-right">الرقم</th>
            <th class="px-4 py-3 text-right">الطابق</th>
            <th class="px-4 py-3 text-right">الطاقة</th>
            <th class="px-4 py-3 text-right">الحالة</th>
            <th class="px-4 py-3 text-center">إجراءات</th>
        </tr></thead>
        <tbody class="divide-y divide-gray-100">
            @forelse($rooms as $r)
            <tr class="hover:bg-gray-50">
                <td class="px-4 py-3 font-semibold">{{ $r->name }}</td>
                <td class="px-4 py-3">{{ $r->room_number ?? '—' }}</td>
                <td class="px-4 py-3">{{ $r->floor ?? '—' }}</td>
                <td class="px-4 py-3">{{ $r->capacity ?? '—' }}</td>
                <td class="px-4 py-3">
                    @php $rStatus=['available'=>['badge-active','متاحة'],'occupied'=>['badge-waiting','مشغولة'],'maintenance'=>['badge-withdrawn','صيانة']]; @endphp
                    <span class="{{ $rStatus[$r->status][0] ?? 'badge-waiting' }}">{{ $rStatus[$r->status][1] ?? $r->status }}</span>
                </td>
                <td class="px-4 py-3 flex justify-center gap-1">
                    <a href="{{ route('rooms.edit', $r->id) }}" class="btn-edit text-xs px-2 py-1">تعديل</a>
                    <form method="POST" action="{{ route('rooms.destroy', $r->id) }}" onsubmit="return confirm('حذف؟')">
                        @csrf @method('DELETE') <button class="btn-danger text-xs px-2 py-1">حذف</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr><td colspan="6" class="text-center py-6 text-gray-400">لا توجد قاعات</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
<div id="add-modal" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
    <div class="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-md">
        <div class="flex justify-between mb-4"><h3 class="font-bold">إضافة قاعة</h3><button onclick="document.getElementById('add-modal').classList.add('hidden')" class="text-gray-400 text-2xl">×</button></div>
        <form method="POST" action="{{ route('rooms.store') }}" class="space-y-3">
            @csrf
            <input name="name" required placeholder="اسم القاعة *" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <input name="room_number" placeholder="رقم القاعة" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <input name="floor" placeholder="الطابق" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <input name="capacity" type="number" placeholder="الطاقة" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <select name="status" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
                <option value="available">متاحة</option>
                <option value="occupied">مشغولة</option>
                <option value="maintenance">صيانة</option>
            </select>
            <div class="flex gap-2"><button type="submit" class="btn-primary flex-1">حفظ</button><button type="button" onclick="document.getElementById('add-modal').classList.add('hidden')" class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg flex-1">إلغاء</button></div>
        </form>
    </div>
</div>
@endsection
