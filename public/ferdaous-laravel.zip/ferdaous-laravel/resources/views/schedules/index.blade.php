@extends('layouts.app')
@section('title', 'الجداول الدراسية')
@section('page-title', 'الجداول الدراسية')

@section('content')
<div class="flex gap-2 mb-4">
    <button onclick="document.getElementById('add-modal').classList.remove('hidden')" class="btn-primary">+ إضافة حصة</button>
    <button onclick="document.getElementById('gen-modal').classList.remove('hidden')" class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg font-semibold text-sm">⚡ توليد تلقائي</button>
</div>

@php $days = ['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت']; @endphp

@foreach($days as $day)
@php $daySchedules = $schedules->where('day_of_week', $day); @endphp
@if($daySchedules->isNotEmpty())
<div class="mb-4">
    <h3 class="font-bold text-gray-700 mb-2 text-sm">{{ $day }}</h3>
    <div class="card overflow-hidden p-0">
        <table class="w-full text-sm">
            <tbody class="divide-y divide-gray-100">
                @foreach($daySchedules as $s)
                <tr class="hover:bg-gray-50">
                    <td class="px-4 py-3 font-mono text-gray-600 w-28">{{ $s->start_time }} — {{ $s->end_time }}</td>
                    <td class="px-4 py-3 font-semibold">{{ $s->group_name }}</td>
                    <td class="px-4 py-3 text-primary">{{ $s->subject_name }}</td>
                    <td class="px-4 py-3">{{ $s->teacher_name }}</td>
                    <td class="px-4 py-3 text-gray-500">{{ $s->room_name ?? '—' }}</td>
                    <td class="px-4 py-3 text-left">
                        <form method="POST" action="{{ route('schedules.destroy', $s->id) }}" onsubmit="return confirm('حذف الحصة؟')">
                            @csrf @method('DELETE')
                            <button class="btn-danger text-xs px-2 py-1">حذف</button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endif
@endforeach

@if($schedules->isEmpty())
<div class="card text-center py-8 text-gray-400">لا توجد حصص مضافة</div>
@endif

{{-- Add Modal --}}
<div id="add-modal" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
    <div class="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-lg overflow-y-auto max-h-screen">
        <div class="flex justify-between items-center mb-4">
            <h3 class="font-bold text-lg">إضافة حصة</h3>
            <button onclick="document.getElementById('add-modal').classList.add('hidden')" class="text-gray-400 text-2xl">×</button>
        </div>
        <form method="POST" action="{{ route('schedules.store') }}" class="space-y-3">
            @csrf
            <select name="day_of_week" required class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
                <option value="">اختر اليوم *</option>
                @foreach($days as $d)<option value="{{ $d }}">{{ $d }}</option>@endforeach
            </select>
            <div class="grid grid-cols-2 gap-3">
                <input type="time" name="start_time" required class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm" placeholder="البداية">
                <input type="time" name="end_time" required class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm" placeholder="النهاية">
            </div>
            <select name="group_id" required class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
                <option value="">الفوج *</option>
                @foreach($groups as $g)<option value="{{ $g->id }}">{{ $g->name }}</option>@endforeach
            </select>
            <select name="subject_id" required class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
                <option value="">المادة *</option>
                @foreach($subjects as $s)<option value="{{ $s->id }}">{{ $s->name }}</option>@endforeach
            </select>
            <select name="teacher_id" required class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
                <option value="">المعلم *</option>
                @foreach($teachers as $t)<option value="{{ $t->id }}">{{ $t->full_name }}</option>@endforeach
            </select>
            <select name="room_id" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
                <option value="">القاعة (اختياري)</option>
                @foreach($rooms as $r)<option value="{{ $r->id }}">{{ $r->name }}</option>@endforeach
            </select>
            <div class="flex gap-2 pt-2">
                <button type="submit" class="btn-primary flex-1">حفظ</button>
                <button type="button" onclick="document.getElementById('add-modal').classList.add('hidden')"
                        class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg flex-1">إلغاء</button>
            </div>
        </form>
    </div>
</div>

{{-- Generate Modal --}}
<div id="gen-modal" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
    <div class="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-lg overflow-y-auto max-h-screen">
        <div class="flex justify-between items-center mb-4">
            <h3 class="font-bold text-lg">توليد جدول تلقائي</h3>
            <button onclick="document.getElementById('gen-modal').classList.add('hidden')" class="text-gray-400 text-2xl">×</button>
        </div>
        <form method="POST" action="{{ route('schedules.generate') }}" class="space-y-3">
            @csrf
            <div>
                <label class="block text-xs font-semibold text-gray-500 mb-2">اختر الأيام</label>
                <div class="flex flex-wrap gap-2">
                    @foreach($days as $d)
                    <label class="cursor-pointer">
                        <input type="checkbox" name="days[]" value="{{ $d }}" class="sr-only peer">
                        <span class="px-3 py-1.5 rounded-lg border-2 border-gray-200 text-sm peer-checked:bg-primary peer-checked:text-white peer-checked:border-primary">{{ $d }}</span>
                    </label>
                    @endforeach
                </div>
            </div>
            <div class="grid grid-cols-2 gap-3">
                <input type="time" name="start_time" required class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
                <input type="time" name="end_time" required class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            </div>
            <select name="group_id" required class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
                <option value="">الفوج *</option>
                @foreach($groups as $g)<option value="{{ $g->id }}">{{ $g->name }}</option>@endforeach
            </select>
            <select name="subject_id" required class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
                <option value="">المادة *</option>
                @foreach($subjects as $s)<option value="{{ $s->id }}">{{ $s->name }}</option>@endforeach
            </select>
            <select name="teacher_id" required class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
                <option value="">المعلم *</option>
                @foreach($teachers as $t)<option value="{{ $t->id }}">{{ $t->full_name }}</option>@endforeach
            </select>
            <div class="flex gap-2 pt-2">
                <button type="submit" class="btn-primary flex-1">توليد</button>
                <button type="button" onclick="document.getElementById('gen-modal').classList.add('hidden')"
                        class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg flex-1">إلغاء</button>
            </div>
        </form>
    </div>
</div>
@endsection
