@extends('layouts.app')
@section('title', 'النسخ الاحتياطي')
@section('page-title', 'النسخ الاحتياطي')

@section('content')
<div class="max-w-lg">
    <div class="card">
        <h3 class="font-bold text-gray-700 mb-3">تنزيل نسخة احتياطية</h3>
        <p class="text-gray-500 text-sm mb-4">يشمل الملف جميع البيانات (طلاب، معلمون، أفواج، حضور، مالية، إعدادات) بصيغة JSON.</p>
        <a href="{{ route('backup.download') }}"
           class="btn-primary inline-flex items-center gap-2">
            💾 تنزيل النسخة الاحتياطية
        </a>
    </div>
</div>
@endsection
