@extends('layouts.app')
@section('title', 'الإعدادات')
@section('page-title', 'إعدادات النظام')

@section('content')
<div class="max-w-2xl">
    <form method="POST" action="{{ route('settings.update') }}" class="space-y-5">
        @csrf

        <div class="card">
            <h3 class="font-bold text-gray-700 mb-4">بيانات المؤسسة</h3>
            <div class="space-y-3">
                <div>
                    <label class="block text-sm font-semibold text-gray-600 mb-1">اسم المؤسسة</label>
                    <input name="school_name" value="{{ $settings['school_name'] ?? '' }}" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-gray-600 mb-1">السنة الدراسية</label>
                    <input name="academic_year" value="{{ $settings['academic_year'] ?? '' }}" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
                </div>
            </div>
        </div>

        <div class="card">
            <h3 class="font-bold text-gray-700 mb-4">الإعدادات المالية</h3>
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-sm font-semibold text-gray-600 mb-1">رسوم الطالب الافتراضية</label>
                    <input name="default_fee" value="{{ $settings['default_fee'] ?? '' }}" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-gray-600 mb-1">الراتب الافتراضي</label>
                    <input name="default_salary" value="{{ $settings['default_salary'] ?? '' }}" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
                </div>
            </div>
        </div>

        <div class="card">
            <h3 class="font-bold text-gray-700 mb-4">رسائل التواصل</h3>
            <div class="space-y-3">
                <div>
                    <label class="block text-sm font-semibold text-gray-600 mb-1">رمز الدولة</label>
                    <input name="country_code" value="{{ $settings['country_code'] ?? '+213' }}" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-gray-600 mb-1">رسالة الغياب</label>
                    <textarea name="absent_message" rows="2" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">{{ $settings['absent_message'] ?? '' }}</textarea>
                    <p class="text-xs text-gray-400 mt-1">المتغيرات: {student_name} {date} {time}</p>
                </div>
                <div>
                    <label class="block text-sm font-semibold text-gray-600 mb-1">رسالة التأخر</label>
                    <textarea name="late_message" rows="2" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">{{ $settings['late_message'] ?? '' }}</textarea>
                </div>
            </div>
        </div>

        <button type="submit" class="btn-primary px-8 py-3">💾 حفظ الإعدادات</button>
    </form>
</div>
@endsection
