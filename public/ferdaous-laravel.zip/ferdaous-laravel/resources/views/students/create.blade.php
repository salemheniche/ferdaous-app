@extends('layouts.app')
@section('title', 'إضافة طالب')
@section('page-title', 'إضافة طالب جديد')

@section('content')
<div class="max-w-2xl">
    <form method="POST" action="{{ route('students.store') }}" class="card space-y-4">
        @csrf
        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">الاسم الأول *</label>
                <input name="first_name" required value="{{ old('first_name') }}"
                       class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-400">
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">اللقب *</label>
                <input name="last_name" required value="{{ old('last_name') }}"
                       class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-400">
            </div>
        </div>
        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">الجنس</label>
                <select name="gender" class="w-full border border-gray-300 rounded-lg px-3 py-2">
                    <option value="">اختر</option>
                    <option value="male">ذكر</option>
                    <option value="female">أنثى</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">رقم الهاتف</label>
                <input name="phone" value="{{ old('phone') }}"
                       class="w-full border border-gray-300 rounded-lg px-3 py-2">
            </div>
        </div>
        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">اسم ولي الأمر</label>
                <input name="guardian_name" value="{{ old('guardian_name') }}"
                       class="w-full border border-gray-300 rounded-lg px-3 py-2">
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">المستوى الدراسي</label>
                <input name="educational_level" value="{{ old('educational_level') }}"
                       class="w-full border border-gray-300 rounded-lg px-3 py-2">
            </div>
        </div>
        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">تاريخ الميلاد</label>
                <input type="date" name="birth_date" value="{{ old('birth_date') }}"
                       class="w-full border border-gray-300 rounded-lg px-3 py-2">
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">تاريخ التسجيل</label>
                <input type="date" name="enrollment_date" value="{{ old('enrollment_date', date('Y-m-d')) }}"
                       class="w-full border border-gray-300 rounded-lg px-3 py-2">
            </div>
        </div>
        <div>
            <label class="block text-sm font-semibold text-gray-700 mb-1">ملاحظات</label>
            <textarea name="notes" rows="3" class="w-full border border-gray-300 rounded-lg px-3 py-2">{{ old('notes') }}</textarea>
        </div>
        <div class="flex gap-3 pt-2">
            <button type="submit" class="btn-primary">حفظ الطالب</button>
            <a href="{{ route('students.index') }}" class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-lg font-semibold">إلغاء</a>
        </div>
    </form>
</div>
@endsection
