@extends('layouts.app')
@section('title', 'تعديل الطالب')
@section('page-title', 'تعديل بيانات الطالب')

@section('content')
<div class="max-w-2xl">
    <form method="POST" action="{{ route('students.update', $student->id) }}" class="card space-y-4">
        @csrf @method('PUT')
        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">الاسم الأول *</label>
                <input name="first_name" required value="{{ $student->first_name }}"
                       class="w-full border border-gray-300 rounded-lg px-3 py-2">
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">اللقب *</label>
                <input name="last_name" required value="{{ $student->last_name }}"
                       class="w-full border border-gray-300 rounded-lg px-3 py-2">
            </div>
        </div>
        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">الجنس</label>
                <select name="gender" class="w-full border border-gray-300 rounded-lg px-3 py-2">
                    <option value="">اختر</option>
                    <option value="male"   {{ $student->gender=='male'   ? 'selected':'' }}>ذكر</option>
                    <option value="female" {{ $student->gender=='female' ? 'selected':'' }}>أنثى</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">رقم الهاتف</label>
                <input name="phone" value="{{ $student->phone }}" class="w-full border border-gray-300 rounded-lg px-3 py-2">
            </div>
        </div>
        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">اسم ولي الأمر</label>
                <input name="guardian_name" value="{{ $student->guardian_name }}" class="w-full border border-gray-300 rounded-lg px-3 py-2">
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">المستوى الدراسي</label>
                <input name="educational_level" value="{{ $student->educational_level }}" class="w-full border border-gray-300 rounded-lg px-3 py-2">
            </div>
        </div>
        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">الحالة</label>
                <select name="status" class="w-full border border-gray-300 rounded-lg px-3 py-2">
                    <option value="waiting"   {{ $student->status=='waiting'   ? 'selected':'' }}>انتظار</option>
                    <option value="active"    {{ $student->status=='active'    ? 'selected':'' }}>نشط</option>
                    <option value="withdrawn" {{ $student->status=='withdrawn' ? 'selected':'' }}>منسحب</option>
                    <option value="graduated" {{ $student->status=='graduated' ? 'selected':'' }}>متخرج</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">تاريخ التسجيل</label>
                <input type="date" name="enrollment_date" value="{{ $student->enrollment_date }}" class="w-full border border-gray-300 rounded-lg px-3 py-2">
            </div>
        </div>
        <div>
            <label class="block text-sm font-semibold text-gray-700 mb-1">ملاحظات</label>
            <textarea name="notes" rows="3" class="w-full border border-gray-300 rounded-lg px-3 py-2">{{ $student->notes }}</textarea>
        </div>
        <div class="flex gap-3 pt-2">
            <button type="submit" class="btn-primary">حفظ التعديلات</button>
            <a href="{{ route('students.index') }}" class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-lg font-semibold">إلغاء</a>
        </div>
    </form>
</div>
@endsection
