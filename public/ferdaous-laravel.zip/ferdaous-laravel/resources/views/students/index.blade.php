@extends('layouts.app')
@section('title', 'الطلاب')
@section('page-title', 'إدارة الطلاب')

@section('content')
{{-- Filters --}}
<form method="GET" class="card mb-4 flex flex-wrap gap-3 items-end">
    <div class="flex-1 min-w-48">
        <label class="text-xs font-semibold text-gray-500 mb-1 block">بحث</label>
        <input name="search" value="{{ request('search') }}" placeholder="اسم أو رقم الطالب..."
               class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-400">
    </div>
    <div>
        <label class="text-xs font-semibold text-gray-500 mb-1 block">الجنس</label>
        <select name="gender" class="border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <option value="">الكل</option>
            <option value="male"   {{ request('gender')=='male'   ? 'selected':'' }}>ذكر</option>
            <option value="female" {{ request('gender')=='female' ? 'selected':'' }}>أنثى</option>
        </select>
    </div>
    <div>
        <label class="text-xs font-semibold text-gray-500 mb-1 block">الحالة</label>
        <select name="status" class="border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <option value="">الكل</option>
            <option value="active"    {{ request('status')=='active'    ? 'selected':'' }}>نشط</option>
            <option value="waiting"   {{ request('status')=='waiting'   ? 'selected':'' }}>انتظار</option>
            <option value="withdrawn" {{ request('status')=='withdrawn' ? 'selected':'' }}>منسحب</option>
            <option value="graduated" {{ request('status')=='graduated' ? 'selected':'' }}>متخرج</option>
        </select>
    </div>
    <button class="btn-primary text-sm">🔍 بحث</button>
    <a href="{{ route('students.index') }}" class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-lg text-sm font-semibold">إعادة تعيين</a>
</form>

{{-- Actions --}}
<div class="flex flex-wrap gap-2 mb-4">
    <a href="{{ route('students.create') }}" class="btn-primary">+ إضافة طالب</a>
    <a href="{{ route('students.export') }}" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-semibold">📥 تصدير Excel</a>
    <a href="{{ route('students.template') }}" class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-lg text-sm font-semibold">📋 قالب الاستيراد</a>
    <button onclick="document.getElementById('import-form').classList.toggle('hidden')"
            class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-semibold">📤 استيراد Excel</button>
</div>

{{-- Import form --}}
<form method="POST" action="{{ route('students.import') }}" enctype="multipart/form-data"
      id="import-form" class="hidden card mb-4 flex items-center gap-3">
    @csrf
    <input type="file" name="file" accept=".csv,.txt" class="border border-gray-300 rounded-lg px-3 py-2 text-sm">
    <button class="btn-primary text-sm">رفع الملف</button>
</form>

{{-- Table --}}
<div class="card overflow-hidden p-0">
    <table class="w-full text-sm">
        <thead class="table-head">
            <tr>
                <th class="px-4 py-3 text-right">رقم الطالب</th>
                <th class="px-4 py-3 text-right">الاسم الكامل</th>
                <th class="px-4 py-3 text-right">الجنس</th>
                <th class="px-4 py-3 text-right">المستوى</th>
                <th class="px-4 py-3 text-right">الحالة</th>
                <th class="px-4 py-3 text-right">تاريخ التسجيل</th>
                <th class="px-4 py-3 text-center">إجراءات</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-100">
            @forelse($students as $student)
            <tr class="hover:bg-gray-50">
                <td class="px-4 py-3 font-mono text-primary font-semibold">{{ $student->student_number }}</td>
                <td class="px-4 py-3 font-semibold">{{ $student->first_name }} {{ $student->last_name }}</td>
                <td class="px-4 py-3">{{ $student->gender === 'male' ? 'ذكر' : 'أنثى' }}</td>
                <td class="px-4 py-3">{{ $student->educational_level ?? '—' }}</td>
                <td class="px-4 py-3">
                    @php
                    $badges = ['active'=>'badge-active','waiting'=>'badge-waiting','withdrawn'=>'badge-withdrawn','graduated'=>'badge-graduated'];
                    $labels = ['active'=>'نشط','waiting'=>'انتظار','withdrawn'=>'منسحب','graduated'=>'متخرج'];
                    @endphp
                    <span class="{{ $badges[$student->status] ?? 'badge-waiting' }}">{{ $labels[$student->status] ?? $student->status }}</span>
                </td>
                <td class="px-4 py-3 text-gray-500">{{ $student->enrollment_date }}</td>
                <td class="px-4 py-3 flex justify-center gap-1">
                    <a href="{{ route('students.show', $student->id) }}" class="bg-gray-100 hover:bg-gray-200 text-gray-700 px-2 py-1 rounded text-xs">عرض</a>
                    <a href="{{ route('students.edit', $student->id) }}" class="btn-edit text-xs px-2 py-1">تعديل</a>
                    <a href="{{ route('students.print', $student->id) }}" target="_blank" class="bg-purple-100 hover:bg-purple-200 text-purple-700 px-2 py-1 rounded text-xs">طباعة</a>
                    <form method="POST" action="{{ route('students.destroy', $student->id) }}"
                          onsubmit="return confirm('هل أنت متأكد من حذف هذا الطالب؟')">
                        @csrf @method('DELETE')
                        <button class="btn-danger text-xs px-2 py-1">حذف</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr><td colspan="7" class="text-center py-8 text-gray-400">لا يوجد طلاب</td></tr>
            @endforelse
        </tbody>
    </table>
    <div class="px-4 py-3 border-t border-gray-100">
        {{ $students->links() }}
    </div>
</div>
@endsection
