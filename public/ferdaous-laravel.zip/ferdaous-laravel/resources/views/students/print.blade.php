<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>ملف الطالب — {{ $student->first_name }} {{ $student->last_name }}</title>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        * { font-family: 'Cairo', sans-serif; margin: 0; padding: 0; box-sizing: border-box; }
        body { background: #fff; color: #1a1a1a; font-size: 14px; }
        .no-print { display: block; }
        @media print { .no-print { display: none !important; } body { font-size: 12px; } }
        .header { background: linear-gradient(135deg, #1a5c35, #0a2b17); color: white; padding: 20px; display: flex; justify-content: space-between; align-items: center; }
        .section { padding: 20px; border-bottom: 1px solid #e5e7eb; }
        .grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        .field label { font-size: 11px; color: #6b7280; display: block; }
        .field span { font-weight: 600; font-size: 14px; }
        .badge { display: inline-block; padding: 2px 10px; border-radius: 999px; font-size: 12px; font-weight: 600; }
        .group-tag { background: #d1fae5; color: #065f46; padding: 4px 12px; border-radius: 999px; display: inline-block; margin: 3px; font-size: 13px; }
    </style>
</head>
<body>
<div class="no-print" style="padding:16px; background:#f0fdf4;">
    <button onclick="window.print()" style="background:#1a5c35;color:white;padding:8px 20px;border-radius:8px;border:none;cursor:pointer;font-family:Cairo,sans-serif;font-size:14px;font-weight:600;">
        🖨️ طباعة
    </button>
    <a href="{{ route('students.show', $student->id) }}" style="margin-right:10px;color:#1a5c35;font-weight:600;text-decoration:none;">رجوع</a>
</div>

<div class="header">
    <div>
        <div style="font-size:18px;font-weight:700;">{{ $schoolName }}</div>
        <div style="font-size:12px;opacity:0.8;">السنة الدراسية: {{ $academicYear }}</div>
    </div>
    <div style="text-align:center;">
        <div style="font-size:28px;font-weight:700;background:rgba(255,255,255,0.2);padding:8px 20px;border-radius:8px;">ملف الطالب</div>
    </div>
</div>

<div class="section">
    <div style="font-size:22px;font-weight:700;color:#1a5c35;margin-bottom:4px;">{{ $student->first_name }} {{ $student->last_name }}</div>
    <div style="color:#6b7280;font-family:monospace;">{{ $student->student_number }}</div>
</div>

<div class="section">
    <h3 style="font-size:14px;font-weight:700;color:#374151;margin-bottom:12px;">البيانات الشخصية</h3>
    <div class="grid2">
        <div class="field"><label>الجنس</label><span>{{ $student->gender === 'male' ? 'ذكر' : 'أنثى' }}</span></div>
        <div class="field"><label>تاريخ الميلاد</label><span>{{ $student->birth_date ?? '—' }}</span></div>
        <div class="field"><label>الهاتف</label><span>{{ $student->phone ?? '—' }}</span></div>
        <div class="field"><label>ولي الأمر</label><span>{{ $student->guardian_name ?? '—' }}</span></div>
        <div class="field"><label>المستوى الدراسي</label><span>{{ $student->educational_level ?? '—' }}</span></div>
        <div class="field"><label>تاريخ التسجيل</label><span>{{ $student->enrollment_date }}</span></div>
        <div class="field"><label>الحالة</label>
            @php $labels = ['active'=>'نشط','waiting'=>'انتظار','withdrawn'=>'منسحب','graduated'=>'متخرج']; @endphp
            <span>{{ $labels[$student->status] ?? $student->status }}</span>
        </div>
    </div>
</div>

<div class="section">
    <h3 style="font-size:14px;font-weight:700;color:#374151;margin-bottom:8px;">الغيابات</h3>
    <div style="font-size:32px;font-weight:700;color:{{ $absenceCount >= 5 ? '#dc2626' : '#1a5c35' }}">{{ $absenceCount }}</div>
    <div style="color:#6b7280;font-size:12px;">غيابة مسجلة {{ $absenceCount >= 5 ? '⚠️ تجاوز الحد' : '' }}</div>
</div>

<div class="section">
    <h3 style="font-size:14px;font-weight:700;color:#374151;margin-bottom:8px;">الأفواج</h3>
    @forelse($groups as $g)
    <span class="group-tag">{{ $g->name }}</span>
    @empty
    <span style="color:#9ca3af;font-size:13px;">غير مسجل في أي فوج</span>
    @endforelse
</div>

@if($student->notes)
<div class="section">
    <h3 style="font-size:14px;font-weight:700;color:#374151;margin-bottom:8px;">ملاحظات</h3>
    <p style="color:#374151;">{{ $student->notes }}</p>
</div>
@endif
</body>
</html>
