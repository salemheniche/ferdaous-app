@extends('layouts.app')
@section('title', 'ملف الطالب')
@section('page-title', 'ملف الطالب')

@section('content')
<div class="max-w-3xl">
    <div class="card mb-4">
        <div class="flex justify-between items-start mb-4">
            <div>
                <h2 class="text-2xl font-bold text-gray-800">{{ $student->first_name }} {{ $student->last_name }}</h2>
                <span class="font-mono text-primary font-semibold text-sm">{{ $student->student_number }}</span>
            </div>
            <div class="flex gap-2">
                <a href="{{ route('students.edit', $student->id) }}" class="btn-edit">تعديل</a>
                <a href="{{ route('students.print', $student->id) }}" target="_blank" class="bg-purple-600 hover:bg-purple-700 text-white px-3 py-1.5 rounded-lg text-sm">طباعة</a>
                <a href="{{ route('students.index') }}" class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-1.5 rounded-lg text-sm">رجوع</a>
            </div>
        </div>
        <div class="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
            <div><span class="text-gray-500">الجنس:</span> <span class="font-semibold">{{ $student->gender === 'male' ? 'ذكر' : 'أنثى' }}</span></div>
            <div><span class="text-gray-500">الهاتف:</span> <span class="font-semibold">{{ $student->phone ?? '—' }}</span></div>
            <div><span class="text-gray-500">ولي الأمر:</span> <span class="font-semibold">{{ $student->guardian_name ?? '—' }}</span></div>
            <div><span class="text-gray-500">المستوى:</span> <span class="font-semibold">{{ $student->educational_level ?? '—' }}</span></div>
            <div><span class="text-gray-500">تاريخ التسجيل:</span> <span class="font-semibold">{{ $student->enrollment_date }}</span></div>
            <div><span class="text-gray-500">الحالة:</span>
                @php $labels = ['active'=>'نشط','waiting'=>'انتظار','withdrawn'=>'منسحب','graduated'=>'متخرج']; @endphp
                <span class="font-semibold">{{ $labels[$student->status] ?? $student->status }}</span>
            </div>
        </div>
        @if($student->notes)
        <div class="mt-3 bg-yellow-50 rounded-lg p-3 text-sm text-yellow-800">{{ $student->notes }}</div>
        @endif
    </div>

    {{-- Absences --}}
    <div class="card mb-4">
        <h3 class="font-bold text-gray-700 mb-2">إحصائيات الغياب</h3>
        <div class="text-3xl font-bold text-red-600">{{ $absenceCount }}</div>
        <div class="text-gray-500 text-sm">غيابات مسجلة</div>
        @if($absenceCount >= 5)
        <div class="mt-2 text-red-600 text-sm font-semibold">⚠️ تجاوز حد الغيابات المسموح (5)</div>
        @endif
    </div>

    {{-- Groups --}}
    <div class="card">
        <h3 class="font-bold text-gray-700 mb-3">الأفواج المسجل فيها</h3>
        @forelse($groups as $g)
        <div class="flex items-center gap-2 bg-green-50 rounded-lg px-3 py-2 mb-2">
            <span class="text-primary font-semibold">{{ $g->name }}</span>
        </div>
        @empty
        <p class="text-gray-400 text-sm">غير مسجل في أي فوج</p>
        @endforelse
    </div>
</div>
@endsection
