@extends('layouts.app')
@section('title', 'تعديل مادة')
@section('page-title', 'تعديل المادة')
@section('content')
<div class="max-w-md">
    <form method="POST" action="{{ route('subjects.update', $subject->id) }}" class="card space-y-3">
        @csrf @method('PUT')
        <input name="name" required value="{{ $subject->name }}" placeholder="الاسم *" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
        <input name="subject_code" value="{{ $subject->subject_code }}" placeholder="الرمز" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
        <input name="weekly_sessions" type="number" value="{{ $subject->weekly_sessions }}" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
        <div class="flex gap-2"><button type="submit" class="btn-primary">حفظ</button><a href="{{ route('subjects.index') }}" class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg font-semibold">إلغاء</a></div>
    </form>
</div>
@endsection
