@extends('layouts.app')
@section('title', 'المواد')
@section('page-title', 'إدارة المواد')
@section('content')
<div class="flex gap-2 mb-4">
    <button onclick="document.getElementById('add-modal').classList.remove('hidden')" class="btn-primary">+ إضافة مادة</button>
</div>
<div class="card overflow-hidden p-0">
    <table class="w-full text-sm">
        <thead class="table-head"><tr>
            <th class="px-4 py-3 text-right">الرمز</th>
            <th class="px-4 py-3 text-right">الاسم</th>
            <th class="px-4 py-3 text-right">الحصص الأسبوعية</th>
            <th class="px-4 py-3 text-center">إجراءات</th>
        </tr></thead>
        <tbody class="divide-y divide-gray-100">
            @forelse($subjects as $s)
            <tr class="hover:bg-gray-50">
                <td class="px-4 py-3 font-mono text-gray-500">{{ $s->subject_code ?? '—' }}</td>
                <td class="px-4 py-3 font-semibold">{{ $s->name }}</td>
                <td class="px-4 py-3">{{ $s->weekly_sessions }}</td>
                <td class="px-4 py-3 flex justify-center gap-1">
                    <a href="{{ route('subjects.edit', $s->id) }}" class="btn-edit text-xs px-2 py-1">تعديل</a>
                    <form method="POST" action="{{ route('subjects.destroy', $s->id) }}" onsubmit="return confirm('حذف؟')">
                        @csrf @method('DELETE') <button class="btn-danger text-xs px-2 py-1">حذف</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr><td colspan="4" class="text-center py-6 text-gray-400">لا توجد مواد</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
<div id="add-modal" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
    <div class="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-md">
        <div class="flex justify-between mb-4"><h3 class="font-bold">إضافة مادة</h3><button onclick="document.getElementById('add-modal').classList.add('hidden')" class="text-gray-400 text-2xl">×</button></div>
        <form method="POST" action="{{ route('subjects.store') }}" class="space-y-3">
            @csrf
            <input name="name" required placeholder="اسم المادة *" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <input name="subject_code" placeholder="الرمز" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <input name="weekly_sessions" type="number" value="1" placeholder="الحصص الأسبوعية" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <div class="flex gap-2"><button type="submit" class="btn-primary flex-1">حفظ</button><button type="button" onclick="document.getElementById('add-modal').classList.add('hidden')" class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg flex-1">إلغاء</button></div>
        </form>
    </div>
</div>
@endsection
