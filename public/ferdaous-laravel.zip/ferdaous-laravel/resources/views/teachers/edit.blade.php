@extends('layouts.app')
@section('title', 'تعديل المعلم')
@section('page-title', 'تعديل بيانات المعلم')
@section('content')
<div class="max-w-md">
    <form method="POST" action="{{ route('teachers.update', $teacher->id) }}" class="card space-y-3">
        @csrf @method('PUT')
        <input name="full_name" required value="{{ $teacher->full_name }}" placeholder="الاسم *" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
        <input name="phone" value="{{ $teacher->phone }}" placeholder="الهاتف" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
        <input name="qualification" value="{{ $teacher->qualification }}" placeholder="المؤهل" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
        <input name="email" value="{{ $teacher->email }}" placeholder="البريد الإلكتروني" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
        <input type="date" name="hire_date" value="{{ $teacher->hire_date }}" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
        <input name="base_salary" value="{{ $teacher->base_salary }}" placeholder="الراتب الأساسي" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
        <select name="status" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <option value="active"   {{ $teacher->status==='active'   ? 'selected':'' }}>نشط</option>
            <option value="inactive" {{ $teacher->status==='inactive' ? 'selected':'' }}>غير نشط</option>
        </select>
        <div class="flex gap-2"><button type="submit" class="btn-primary">حفظ</button><a href="{{ route('teachers.index') }}" class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg font-semibold">إلغاء</a></div>
    </form>
</div>
@endsection
