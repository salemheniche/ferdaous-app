@extends('layouts.app')
@section('title', 'المعلمون')
@section('page-title', 'إدارة المعلمين')

@section('content')
<div class="flex gap-2 mb-4">
    <button onclick="document.getElementById('add-modal').classList.remove('hidden')" class="btn-primary">+ إضافة معلم</button>
</div>

<div class="card overflow-hidden p-0">
    <table class="w-full text-sm">
        <thead class="table-head">
            <tr>
                <th class="px-4 py-3 text-right">رقم المعلم</th>
                <th class="px-4 py-3 text-right">الاسم الكامل</th>
                <th class="px-4 py-3 text-right">الهاتف</th>
                <th class="px-4 py-3 text-right">المؤهل</th>
                <th class="px-4 py-3 text-right">الحالة</th>
                <th class="px-4 py-3 text-center">إجراءات</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-100">
            @forelse($teachers as $t)
            <tr class="hover:bg-gray-50">
                <td class="px-4 py-3 font-mono text-primary font-semibold">{{ $t->teacher_number }}</td>
                <td class="px-4 py-3 font-semibold">{{ $t->full_name }}</td>
                <td class="px-4 py-3">{{ $t->phone ?? '—' }}</td>
                <td class="px-4 py-3">{{ $t->qualification ?? '—' }}</td>
                <td class="px-4 py-3">
                    <span class="{{ $t->status === 'active' ? 'badge-active' : 'badge-withdrawn' }}">
                        {{ $t->status === 'active' ? 'نشط' : 'غير نشط' }}
                    </span>
                </td>
                <td class="px-4 py-3 flex justify-center gap-1">
                    <a href="{{ route('teachers.edit', $t->id) }}" class="btn-edit text-xs px-2 py-1">تعديل</a>
                    <button onclick="openAssignModal({{ $t->id }}, '{{ $t->full_name }}')"
                            class="bg-indigo-100 hover:bg-indigo-200 text-indigo-700 px-2 py-1 rounded text-xs">الأفواج</button>
                    <form method="POST" action="{{ route('teachers.destroy', $t->id) }}"
                          onsubmit="return confirm('حذف المعلم؟')">
                        @csrf @method('DELETE')
                        <button class="btn-danger text-xs px-2 py-1">حذف</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr><td colspan="6" class="text-center py-8 text-gray-400">لا يوجد معلمون</td></tr>
            @endforelse
        </tbody>
    </table>
</div>

{{-- Add Teacher Modal --}}
<div id="add-modal" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
    <div class="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-lg">
        <div class="flex justify-between items-center mb-4">
            <h3 class="font-bold text-lg">إضافة معلم</h3>
            <button onclick="document.getElementById('add-modal').classList.add('hidden')" class="text-gray-400 hover:text-gray-600 text-2xl">×</button>
        </div>
        <form method="POST" action="{{ route('teachers.store') }}" class="space-y-3">
            @csrf
            <input name="full_name" required placeholder="الاسم الكامل *" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <input name="phone" placeholder="رقم الهاتف" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <input name="qualification" placeholder="المؤهل العلمي" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <input name="base_salary" placeholder="الراتب الأساسي" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <div class="border border-gray-200 rounded-lg p-3 bg-gray-50">
                <label class="flex items-center gap-2 cursor-pointer mb-2">
                    <input type="checkbox" name="create_user" value="1" id="create-user-cb" onchange="document.getElementById('user-pass-row').classList.toggle('hidden', !this.checked)">
                    <span class="text-sm font-semibold">إنشاء حساب دخول للمعلم</span>
                </label>
                <div id="user-pass-row" class="hidden">
                    <input name="user_password" type="password" placeholder="كلمة المرور" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
                </div>
            </div>
            <div class="flex gap-2 pt-2">
                <button type="submit" class="btn-primary flex-1">حفظ</button>
                <button type="button" onclick="document.getElementById('add-modal').classList.add('hidden')"
                        class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg flex-1">إلغاء</button>
            </div>
        </form>
    </div>
</div>

{{-- Assign Groups Modal --}}
<div id="assign-modal" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
    <div class="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-md">
        <div class="flex justify-between items-center mb-4">
            <h3 class="font-bold text-lg" id="assign-title">تعيين الأفواج</h3>
            <button onclick="document.getElementById('assign-modal').classList.add('hidden')" class="text-gray-400 hover:text-gray-600 text-2xl">×</button>
        </div>
        <form id="assign-form" method="POST" class="space-y-3">
            @csrf
            <div class="space-y-2 max-h-64 overflow-y-auto">
                @foreach($groups as $g)
                <label class="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 cursor-pointer">
                    <input type="checkbox" name="group_ids[]" value="{{ $g->id }}" class="w-4 h-4">
                    <span class="font-semibold text-sm">{{ $g->name }}</span>
                </label>
                @endforeach
            </div>
            <div class="flex gap-2 pt-2">
                <button type="submit" class="btn-primary flex-1">حفظ</button>
                <button type="button" onclick="document.getElementById('assign-modal').classList.add('hidden')"
                        class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg flex-1">إلغاء</button>
            </div>
        </form>
    </div>
</div>

@push('scripts')
<script>
function openAssignModal(teacherId, name) {
    document.getElementById('assign-title').textContent = 'أفواج: ' + name;
    document.getElementById('assign-form').action = '/teachers/' + teacherId + '/groups';
    document.getElementById('assign-modal').classList.remove('hidden');
}
</script>
@endpush
@endsection
