@extends('layouts.app')
@section('title', 'المستخدمون')
@section('page-title', 'إدارة المستخدمين')

@section('content')
<div class="flex gap-2 mb-4">
    <button onclick="document.getElementById('add-modal').classList.remove('hidden')" class="btn-primary">+ إضافة مستخدم</button>
</div>

<div class="card overflow-hidden p-0">
    <table class="w-full text-sm">
        <thead class="table-head">
            <tr>
                <th class="px-4 py-3 text-right">اسم المستخدم</th>
                <th class="px-4 py-3 text-right">الاسم الكامل</th>
                <th class="px-4 py-3 text-right">الدور</th>
                <th class="px-4 py-3 text-right">الهاتف</th>
                <th class="px-4 py-3 text-right">الحالة</th>
                <th class="px-4 py-3 text-center">إجراءات</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-100">
            @forelse($users as $u)
            <tr class="hover:bg-gray-50">
                <td class="px-4 py-3 font-mono font-semibold text-primary">{{ $u->username }}</td>
                <td class="px-4 py-3">{{ $u->full_name ?? '—' }}</td>
                <td class="px-4 py-3">
                    <span class="{{ $u->role === 'admin' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700' }} text-xs px-2 py-0.5 rounded-full">
                        {{ $u->role === 'admin' ? 'مدير' : 'معلم' }}
                    </span>
                </td>
                <td class="px-4 py-3">{{ $u->phone ?? '—' }}</td>
                <td class="px-4 py-3">
                    <span class="{{ $u->status === 'active' ? 'badge-active' : 'badge-withdrawn' }}">
                        {{ $u->status === 'active' ? 'نشط' : 'غير نشط' }}
                    </span>
                </td>
                <td class="px-4 py-3 flex justify-center gap-1">
                    <button onclick="openEditModal({{ $u->id }}, '{{ $u->username }}', '{{ $u->full_name }}', '{{ $u->phone }}', '{{ $u->role }}', '{{ $u->status }}')"
                            class="btn-edit text-xs px-2 py-1">تعديل</button>
                    @if($u->id != ($authUser['id'] ?? 0))
                    <form method="POST" action="{{ route('users.destroy', $u->id) }}" onsubmit="return confirm('حذف المستخدم؟')">
                        @csrf @method('DELETE') <button class="btn-danger text-xs px-2 py-1">حذف</button>
                    </form>
                    @endif
                </td>
            </tr>
            @empty
            <tr><td colspan="6" class="text-center py-8 text-gray-400">لا يوجد مستخدمون</td></tr>
            @endforelse
        </tbody>
    </table>
</div>

{{-- Add Modal --}}
<div id="add-modal" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
    <div class="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-md">
        <div class="flex justify-between mb-4"><h3 class="font-bold">إضافة مستخدم</h3><button onclick="document.getElementById('add-modal').classList.add('hidden')" class="text-gray-400 text-2xl">×</button></div>
        <form method="POST" action="{{ route('users.store') }}" class="space-y-3">
            @csrf
            <input name="username" required placeholder="اسم المستخدم *" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <input name="password" type="password" required placeholder="كلمة المرور *" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <input name="full_name" placeholder="الاسم الكامل" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <input name="phone" placeholder="رقم الهاتف" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <select name="role" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
                <option value="admin">مدير</option><option value="teacher">معلم</option>
            </select>
            <div class="flex gap-2"><button type="submit" class="btn-primary flex-1">حفظ</button><button type="button" onclick="document.getElementById('add-modal').classList.add('hidden')" class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg flex-1">إلغاء</button></div>
        </form>
    </div>
</div>

{{-- Edit Modal --}}
<div id="edit-modal" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
    <div class="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-md">
        <div class="flex justify-between mb-4"><h3 class="font-bold">تعديل المستخدم</h3><button onclick="document.getElementById('edit-modal').classList.add('hidden')" class="text-gray-400 text-2xl">×</button></div>
        <form id="edit-form" method="POST" class="space-y-3">
            @csrf @method('PUT')
            <input name="password" type="password" placeholder="كلمة مرور جديدة (اتركه فارغاً للإبقاء)" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <input name="full_name" id="edit-full-name" placeholder="الاسم الكامل" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <input name="phone" id="edit-phone" placeholder="الهاتف" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
            <select name="role" id="edit-role" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
                <option value="admin">مدير</option><option value="teacher">معلم</option>
            </select>
            <select name="status" id="edit-status" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
                <option value="active">نشط</option><option value="inactive">غير نشط</option>
            </select>
            <div class="flex gap-2"><button type="submit" class="btn-primary flex-1">حفظ</button><button type="button" onclick="document.getElementById('edit-modal').classList.add('hidden')" class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg flex-1">إلغاء</button></div>
        </form>
    </div>
</div>

@push('scripts')
<script>
function openEditModal(id, username, fullName, phone, role, status) {
    document.getElementById('edit-form').action = '/users/' + id;
    document.getElementById('edit-full-name').value = fullName;
    document.getElementById('edit-phone').value = phone;
    document.getElementById('edit-role').value = role;
    document.getElementById('edit-status').value = status;
    document.getElementById('edit-modal').classList.remove('hidden');
}
</script>
@endpush
@endsection
