<?php

use Illuminate\Support\Facades\Schedule;

// No scheduled commands currently
